-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: nexus_network
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `nexus_network`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `nexus_network` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;

USE `nexus_network`;

--
-- Table structure for table `avaliacoes`
--

DROP TABLE IF EXISTS `avaliacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `avaliacoes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cliente_id` int(10) unsigned NOT NULL,
  `prestador_id` int(10) unsigned NOT NULL,
  `nota` tinyint(3) unsigned NOT NULL,
  `comentario` varchar(500) NOT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_avaliacao` (`cliente_id`,`prestador_id`),
  KEY `idx_avaliacoes_prestador` (`prestador_id`),
  CONSTRAINT `fk_avaliacao_cliente` FOREIGN KEY (`cliente_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_avaliacao_prestador` FOREIGN KEY (`prestador_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ck_avaliacao_nota` CHECK (`nota` between 1 and 5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avaliacoes`
--

LOCK TABLES `avaliacoes` WRITE;
/*!40000 ALTER TABLE `avaliacoes` DISABLE KEYS */;
/*!40000 ALTER TABLE `avaliacoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `buscas`
--

DROP TABLE IF EXISTS `buscas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buscas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `categoria_id` int(10) unsigned DEFAULT NULL,
  `termo` varchar(100) DEFAULT NULL,
  `resultados` int(10) unsigned NOT NULL DEFAULT 0,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_buscas_data` (`criado_em`),
  KEY `idx_buscas_categoria` (`categoria_id`),
  CONSTRAINT `fk_busca_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buscas`
--

LOCK TABLES `buscas` WRITE;
/*!40000 ALTER TABLE `buscas` DISABLE KEYS */;
/*!40000 ALTER TABLE `buscas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(60) NOT NULL,
  `slug` varchar(60) NOT NULL,
  `icone` varchar(40) NOT NULL,
  `descricao` varchar(160) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_categorias_slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES (1,'Reparos e manutenção','reparos','fa-screwdriver-wrench','Eletricistas, encanadores e consertos em geral'),(2,'Reformas e construção','reformas','fa-trowel-bricks','Pedreiros, pintores e acabamento'),(3,'Limpeza','limpeza','fa-broom','Diaristas, faxinas e limpeza pós-obra'),(4,'Tecnologia','tecnologia','fa-laptop-code','Suporte técnico, redes e desenvolvimento'),(5,'Aulas e cursos','aulas','fa-graduation-cap','Reforço escolar, idiomas e música'),(6,'Beleza e bem-estar','beleza','fa-spa','Cabelo, maquiagem, estética e personal'),(7,'Eventos','eventos','fa-champagne-glasses','Fotografia, buffet, decoração e DJ'),(8,'Automotivo','automotivo','fa-car','Mecânica, funilaria e lavagem');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contatos`
--

DROP TABLE IF EXISTS `contatos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contatos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(120) NOT NULL,
  `email` varchar(150) NOT NULL,
  `telefone` varchar(11) DEFAULT NULL,
  `assunto` enum('duvida','problema','sugestao','parceria','outro') NOT NULL,
  `mensagem` text NOT NULL,
  `status` enum('novo','lido','respondido') NOT NULL DEFAULT 'novo',
  `resposta` text DEFAULT NULL,
  `respondido_em` datetime DEFAULT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_contatos_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contatos`
--

LOCK TABLES `contatos` WRITE;
/*!40000 ALTER TABLE `contatos` DISABLE KEYS */;
/*!40000 ALTER TABLE `contatos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversas`
--

DROP TABLE IF EXISTS `conversas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conversas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cliente_id` int(10) unsigned NOT NULL,
  `prestador_id` int(10) unsigned NOT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_conversa` (`cliente_id`,`prestador_id`),
  KEY `idx_conversas_prestador` (`prestador_id`),
  CONSTRAINT `fk_conversa_cliente` FOREIGN KEY (`cliente_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_conversa_prestador` FOREIGN KEY (`prestador_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversas`
--

LOCK TABLES `conversas` WRITE;
/*!40000 ALTER TABLE `conversas` DISABLE KEYS */;
/*!40000 ALTER TABLE `conversas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `denuncias`
--

DROP TABLE IF EXISTS `denuncias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `denuncias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `denunciante_id` int(10) unsigned NOT NULL,
  `prestador_id` int(10) unsigned DEFAULT NULL,
  `avaliacao_id` int(10) unsigned DEFAULT NULL,
  `motivo` enum('spam','ofensivo','falso','golpe','outro') NOT NULL,
  `detalhes` varchar(500) DEFAULT NULL,
  `status` enum('aberta','resolvida','descartada') NOT NULL DEFAULT 'aberta',
  `resolvido_em` datetime DEFAULT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_denuncias_status` (`status`,`criado_em`),
  KEY `idx_denuncias_prestador` (`prestador_id`),
  KEY `idx_denuncias_avaliacao` (`avaliacao_id`),
  KEY `fk_denuncia_denunciante` (`denunciante_id`),
  CONSTRAINT `fk_denuncia_avaliacao` FOREIGN KEY (`avaliacao_id`) REFERENCES `avaliacoes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_denuncia_denunciante` FOREIGN KEY (`denunciante_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_denuncia_prestador` FOREIGN KEY (`prestador_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `denuncias`
--

LOCK TABLES `denuncias` WRITE;
/*!40000 ALTER TABLE `denuncias` DISABLE KEYS */;
/*!40000 ALTER TABLE `denuncias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geocode_cache`
--

DROP TABLE IF EXISTS `geocode_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geocode_cache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cidade` varchar(100) NOT NULL,
  `estado` char(2) NOT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_geocode_cidade` (`cidade`,`estado`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geocode_cache`
--

LOCK TABLES `geocode_cache` WRITE;
/*!40000 ALTER TABLE `geocode_cache` DISABLE KEYS */;
INSERT INTO `geocode_cache` VALUES (1,'Presidente Prudente','SP',-22.12560000,-51.38890000,'2026-10-15 02:04:54'),(2,'Álvares Machado','SP',-22.07640000,-51.47220000,'2026-10-15 02:04:54'),(3,'Regente Feijó','SP',-22.22140000,-51.30280000,'2026-10-15 02:04:54'),(4,'Pirapozinho','SP',-22.27530000,-51.50000000,'2026-10-15 02:04:54'),(5,'Martinópolis','SP',-22.14580000,-51.17080000,'2026-10-15 02:04:54'),(6,'Presidente Venceslau','SP',-21.87610000,-51.84360000,'2026-10-15 02:04:54'),(7,'Presidente Epitácio','SP',-21.76330000,-52.11560000,'2026-10-15 02:04:54'),(8,'Santo Anastácio','SP',-21.97750000,-51.65220000,'2026-10-15 02:04:54'),(9,'Assis','SP',-22.66110000,-50.41220000,'2026-10-15 02:04:54'),(10,'Marília','SP',-22.21390000,-49.94580000,'2026-10-15 02:04:54'),(11,'São Paulo','SP',-23.55050000,-46.63330000,'2026-10-15 02:04:54'),(12,'Campinas','SP',-22.90560000,-47.06080000,'2026-10-15 02:04:54');
/*!40000 ALTER TABLE `geocode_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensagens`
--

DROP TABLE IF EXISTS `mensagens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mensagens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `conversa_id` int(10) unsigned NOT NULL,
  `remetente_id` int(10) unsigned NOT NULL,
  `conteudo` text NOT NULL,
  `lida` tinyint(1) NOT NULL DEFAULT 0,
  `enviada_em` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_mensagens_conversa` (`conversa_id`,`id`),
  KEY `fk_mensagem_remetente` (`remetente_id`),
  CONSTRAINT `fk_mensagem_conversa` FOREIGN KEY (`conversa_id`) REFERENCES `conversas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mensagem_remetente` FOREIGN KEY (`remetente_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensagens`
--

LOCK TABLES `mensagens` WRITE;
/*!40000 ALTER TABLE `mensagens` DISABLE KEYS */;
/*!40000 ALTER TABLE `mensagens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prestador_categorias`
--

DROP TABLE IF EXISTS `prestador_categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prestador_categorias` (
  `prestador_id` int(10) unsigned NOT NULL,
  `categoria_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`prestador_id`,`categoria_id`),
  KEY `fk_pc_categoria` (`categoria_id`),
  CONSTRAINT `fk_pc_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pc_prestador` FOREIGN KEY (`prestador_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prestador_categorias`
--

LOCK TABLES `prestador_categorias` WRITE;
/*!40000 ALTER TABLE `prestador_categorias` DISABLE KEYS */;
/*!40000 ALTER TABLE `prestador_categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prestador_horarios`
--

DROP TABLE IF EXISTS `prestador_horarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prestador_horarios` (
  `prestador_id` int(10) unsigned NOT NULL,
  `dia_semana` tinyint(3) unsigned NOT NULL,
  `inicio` time NOT NULL,
  `fim` time NOT NULL,
  PRIMARY KEY (`prestador_id`,`dia_semana`),
  CONSTRAINT `fk_horario_prestador` FOREIGN KEY (`prestador_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ck_horario_dia` CHECK (`dia_semana` between 0 and 6),
  CONSTRAINT `ck_horario_periodo` CHECK (`fim` > `inicio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prestador_horarios`
--

LOCK TABLES `prestador_horarios` WRITE;
/*!40000 ALTER TABLE `prestador_horarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `prestador_horarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prestador_perfis`
--

DROP TABLE IF EXISTS `prestador_perfis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prestador_perfis` (
  `usuario_id` int(10) unsigned NOT NULL,
  `profissao` varchar(80) NOT NULL,
  `descricao` text DEFAULT NULL,
  `preco_min` decimal(10,2) DEFAULT NULL,
  `preco_max` decimal(10,2) DEFAULT NULL,
  `verificado_em` datetime DEFAULT NULL COMMENT 'Selo de verificado, concedido por um admin',
  PRIMARY KEY (`usuario_id`),
  CONSTRAINT `fk_perfil_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ck_perfil_precos` CHECK (`preco_min` is null or `preco_max` is null or `preco_min` <= `preco_max`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prestador_perfis`
--

LOCK TABLES `prestador_perfis` WRITE;
/*!40000 ALTER TABLE `prestador_perfis` DISABLE KEYS */;
/*!40000 ALTER TABLE `prestador_perfis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `redefinicoes_senha`
--

DROP TABLE IF EXISTS `redefinicoes_senha`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `redefinicoes_senha` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario_id` int(10) unsigned NOT NULL,
  `codigo_hash` varchar(255) NOT NULL,
  `tentativas` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `usado` tinyint(1) NOT NULL DEFAULT 0,
  `expira_em` datetime NOT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_redefinicoes_usuario` (`usuario_id`),
  CONSTRAINT `fk_redefinicao_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `redefinicoes_senha`
--

LOCK TABLES `redefinicoes_senha` WRITE;
/*!40000 ALTER TABLE `redefinicoes_senha` DISABLE KEYS */;
/*!40000 ALTER TABLE `redefinicoes_senha` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipo` enum('cliente','prestador','admin') NOT NULL,
  `nome` varchar(120) NOT NULL,
  `email` varchar(150) NOT NULL,
  `senha` varchar(255) DEFAULT NULL COMMENT 'NULL para contas criadas só com Google',
  `cpf` char(11) DEFAULT NULL,
  `data_nasc` date DEFAULT NULL,
  `genero` varchar(30) DEFAULT NULL,
  `telefone` varchar(11) DEFAULT NULL,
  `estado` char(2) DEFAULT NULL,
  `cidade` varchar(100) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `foto` varchar(500) DEFAULT NULL,
  `google_id` varchar(64) DEFAULT NULL,
  `suspenso_em` datetime DEFAULT NULL COMMENT 'Preenchido quando um admin suspende a conta',
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  `atualizado_em` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_usuarios_email` (`email`),
  UNIQUE KEY `uq_usuarios_cpf` (`cpf`),
  UNIQUE KEY `uq_usuarios_google` (`google_id`),
  KEY `idx_usuarios_tipo` (`tipo`),
  KEY `idx_usuarios_local` (`latitude`,`longitude`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-15 13:13:34
