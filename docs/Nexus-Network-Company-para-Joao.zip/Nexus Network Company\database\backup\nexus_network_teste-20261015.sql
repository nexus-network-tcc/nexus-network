-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: nexus_network_teste
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `nexus_network_teste`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `nexus_network_teste` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;

USE `nexus_network_teste`;

--
-- Table structure for table `avaliacoes`
--

DROP TABLE IF EXISTS `avaliacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `avaliacoes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cliente_id` int(10) unsigned NOT NULL,
  `prestador_id` int(10) unsigned NOT NULL,
  `nota` tinyint(3) unsigned NOT NULL,
  `comentario` varchar(500) NOT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_avaliacao` (`cliente_id`,`prestador_id`),
  KEY `idx_avaliacoes_prestador` (`prestador_id`),
  CONSTRAINT `fk_avaliacao_cliente` FOREIGN KEY (`cliente_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_avaliacao_prestador` FOREIGN KEY (`prestador_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ck_avaliacao_nota` CHECK (`nota` between 1 and 5)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avaliacoes`
--

LOCK TABLES `avaliacoes` WRITE;
/*!40000 ALTER TABLE `avaliacoes` DISABLE KEYS */;
INSERT INTO `avaliacoes` VALUES (1,48,3,2,'Não ficou como combinamos e foi difícil de remarcar.','2026-04-21 02:37:21'),(2,59,3,2,'Não ficou como combinamos e foi difícil de remarcar.','2026-08-25 02:37:21'),(3,60,3,3,'Serviço ok, mas demorou mais do que o combinado.','2026-04-21 02:37:21'),(4,46,4,4,'Atencioso e organizado, recomendo.','2026-08-08 02:37:21'),(5,62,4,4,'Atencioso e organizado, recomendo.','2026-09-28 02:37:21'),(6,47,5,3,'Atendimento razoável, esperava um pouco mais.','2026-07-07 02:37:21'),(7,53,5,3,'Serviço ok, mas demorou mais do que o combinado.','2026-08-28 02:37:21'),(8,54,5,2,'Não ficou como combinamos e foi difícil de remarcar.','2026-07-01 02:37:21'),(9,56,5,2,'Não ficou como combinamos e foi difícil de remarcar.','2026-09-12 02:37:21'),(10,59,5,4,'Atencioso e organizado, recomendo.','2026-09-20 02:37:21'),(11,63,5,3,'Serviço ok, mas demorou mais do que o combinado.','2026-06-02 02:37:21'),(12,64,5,3,'Resolveu o problema, porém precisou voltar uma segunda vez.','2026-10-14 02:37:21'),(13,65,5,4,'Gostei bastante, preço dentro do combinado.','2026-09-17 02:37:21'),(14,46,6,4,'Bom serviço, só atrasou um pouco para chegar.','2026-05-11 02:37:21'),(15,48,6,5,'Atendimento excelente do começo ao fim. Já indiquei para a família.','2026-07-17 02:37:21'),(16,62,6,3,'Atendimento razoável, esperava um pouco mais.','2026-09-17 02:37:21'),(17,67,6,4,'Atencioso e organizado, recomendo.','2026-10-10 02:37:21'),(18,56,7,4,'Trabalho bem feito, poderia ter limpado melhor depois.','2026-09-05 02:37:21'),(19,58,7,4,'Trabalho bem feito, poderia ter limpado melhor depois.','2026-07-11 02:37:21'),(20,61,7,3,'Resolveu o problema, porém precisou voltar uma segunda vez.','2026-07-03 02:37:21'),(21,66,7,2,'Não ficou como combinamos e foi difícil de remarcar.','2026-06-16 02:37:21'),(22,49,9,3,'Resolveu o problema, porém precisou voltar uma segunda vez.','2026-06-19 02:37:21'),(23,57,9,3,'Atendimento razoável, esperava um pouco mais.','2026-09-29 02:37:21'),(24,51,10,5,'Serviço impecável, recomendo de olhos fechados!','2026-06-02 02:37:21'),(25,53,10,5,'Serviço impecável, recomendo de olhos fechados!','2026-07-13 02:37:21'),(26,55,10,4,'Atencioso e organizado, recomendo.','2026-06-15 02:37:21'),(27,56,10,4,'Gostei bastante, preço dentro do combinado.','2026-05-25 02:37:21'),(28,64,10,4,'Atencioso e organizado, recomendo.','2026-06-21 02:37:21'),(29,66,10,4,'Atencioso e organizado, recomendo.','2026-08-03 02:37:21'),(30,47,11,4,'Trabalho bem feito, poderia ter limpado melhor depois.','2026-08-06 02:37:21'),(31,54,11,5,'Serviço impecável, recomendo de olhos fechados!','2026-08-25 02:37:21'),(32,62,11,5,'Muito profissional, pontual e caprichoso.','2026-05-25 02:37:21'),(33,64,11,5,'Atendimento excelente do começo ao fim. Já indiquei para a família.','2026-08-18 02:37:21'),(34,66,11,5,'Atendimento excelente do começo ao fim. Já indiquei para a família.','2026-07-20 02:37:21'),(35,61,12,5,'Resolveu tudo rapidamente e com preço justo.','2026-06-25 02:37:21'),(36,52,13,5,'Muito profissional, pontual e caprichoso.','2026-04-20 02:37:21'),(37,64,13,5,'Atendimento excelente do começo ao fim. Já indiquei para a família.','2026-04-19 02:37:21'),(38,49,14,4,'Gostei bastante, preço dentro do combinado.','2026-05-24 02:37:21'),(39,64,14,4,'Bom serviço, só atrasou um pouco para chegar.','2026-06-16 02:37:21'),(40,1,15,3,'Resolveu o problema, porém precisou voltar uma segunda vez.','2026-04-24 02:37:21'),(41,44,15,4,'Gostei bastante, preço dentro do combinado.','2026-09-28 02:37:21'),(42,60,15,3,'Atendimento razoável, esperava um pouco mais.','2026-06-01 02:37:21'),(43,67,15,2,'Não ficou como combinamos e foi difícil de remarcar.','2026-06-26 02:37:21'),(44,44,16,4,'Gostei bastante, preço dentro do combinado.','2026-04-24 02:37:21'),(45,45,16,3,'Resolveu o problema, porém precisou voltar uma segunda vez.','2026-05-09 02:37:21'),(46,47,16,4,'Bom serviço, só atrasou um pouco para chegar.','2026-04-20 02:37:21'),(47,51,16,3,'Resolveu o problema, porém precisou voltar uma segunda vez.','2026-05-13 02:37:21'),(48,52,16,4,'Trabalho bem feito, poderia ter limpado melhor depois.','2026-07-10 02:37:21'),(49,54,16,4,'Trabalho bem feito, poderia ter limpado melhor depois.','2026-05-29 02:37:21'),(50,45,17,4,'Trabalho bem feito, poderia ter limpado melhor depois.','2026-07-23 02:37:21'),(51,54,17,2,'Não ficou como combinamos e foi difícil de remarcar.','2026-07-03 02:37:21'),(52,56,17,3,'Atendimento razoável, esperava um pouco mais.','2026-05-09 02:37:21'),(53,66,17,3,'Atendimento razoável, esperava um pouco mais.','2026-09-23 02:37:21'),(54,67,17,4,'Bom serviço, só atrasou um pouco para chegar.','2026-09-11 02:37:21'),(55,61,18,3,'Serviço ok, mas demorou mais do que o combinado.','2026-07-09 02:37:21'),(56,1,19,3,'Resolveu o problema, porém precisou voltar uma segunda vez.','2026-08-16 02:37:21'),(57,43,19,3,'Serviço ok, mas demorou mais do que o combinado.','2026-10-03 02:37:21'),(58,59,19,4,'Gostei bastante, preço dentro do combinado.','2026-08-16 02:37:21'),(59,60,19,3,'Atendimento razoável, esperava um pouco mais.','2026-09-27 02:37:21'),(60,1,20,4,'Bom serviço, só atrasou um pouco para chegar.','2026-07-22 02:37:21'),(61,67,20,3,'Serviço ok, mas demorou mais do que o combinado.','2026-08-24 02:37:21'),(62,1,21,3,'Atendimento razoável, esperava um pouco mais.','2026-05-09 02:37:21'),(63,45,21,3,'Resolveu o problema, porém precisou voltar uma segunda vez.','2026-07-10 02:37:21'),(64,46,21,2,'Não ficou como combinamos e foi difícil de remarcar.','2026-08-27 02:37:21'),(65,56,21,4,'Gostei bastante, preço dentro do combinado.','2026-07-07 02:37:21'),(66,62,21,3,'Serviço ok, mas demorou mais do que o combinado.','2026-05-30 02:37:21'),(67,54,22,2,'Não ficou como combinamos e foi difícil de remarcar.','2026-07-10 02:37:21'),(68,56,22,3,'Resolveu o problema, porém precisou voltar uma segunda vez.','2026-04-24 02:37:21'),(69,60,22,3,'Serviço ok, mas demorou mais do que o combinado.','2026-07-18 02:37:21'),(70,65,22,4,'Gostei bastante, preço dentro do combinado.','2026-06-23 02:37:21'),(71,53,23,3,'Atendimento razoável, esperava um pouco mais.','2026-09-26 02:37:21'),(72,58,23,4,'Atencioso e organizado, recomendo.','2026-06-09 02:37:21'),(73,62,23,3,'Serviço ok, mas demorou mais do que o combinado.','2026-07-22 02:37:21'),(74,63,23,4,'Trabalho bem feito, poderia ter limpado melhor depois.','2026-05-30 02:37:21'),(75,65,23,3,'Resolveu o problema, porém precisou voltar uma segunda vez.','2026-06-26 02:37:21'),(76,66,23,3,'Resolveu o problema, porém precisou voltar uma segunda vez.','2026-04-25 02:37:21'),(77,51,24,5,'Muito profissional, pontual e caprichoso.','2026-05-31 02:37:21'),(78,67,24,3,'Atendimento razoável, esperava um pouco mais.','2026-10-05 02:37:21'),(79,47,25,2,'Não ficou como combinamos e foi difícil de remarcar.','2026-07-20 02:37:21'),(80,50,25,4,'Atencioso e organizado, recomendo.','2026-09-24 02:37:21'),(81,51,25,3,'Resolveu o problema, porém precisou voltar uma segunda vez.','2026-06-26 02:37:21'),(82,52,25,3,'Atendimento razoável, esperava um pouco mais.','2026-09-02 02:37:21'),(83,64,25,3,'Serviço ok, mas demorou mais do que o combinado.','2026-10-12 02:37:21'),(84,67,25,2,'Não ficou como combinamos e foi difícil de remarcar.','2026-06-18 02:37:21'),(85,47,26,3,'Serviço ok, mas demorou mais do que o combinado.','2026-09-05 02:37:21'),(86,1,27,3,'Resolveu o problema, porém precisou voltar uma segunda vez.','2026-07-05 02:37:21'),(87,61,27,4,'Bom serviço, só atrasou um pouco para chegar.','2026-04-19 02:37:21'),(88,64,27,4,'Gostei bastante, preço dentro do combinado.','2026-05-06 02:37:21'),(89,46,28,4,'Gostei bastante, preço dentro do combinado.','2026-05-19 02:37:21'),(90,51,28,5,'Resolveu tudo rapidamente e com preço justo.','2026-06-29 02:37:21'),(91,53,28,5,'Superou as expectativas, voltarei a contratar com certeza.','2026-08-25 02:37:21'),(92,60,28,5,'Serviço impecável, recomendo de olhos fechados!','2026-08-14 02:37:21'),(93,62,28,4,'Trabalho bem feito, poderia ter limpado melhor depois.','2026-06-07 02:37:21'),(94,67,28,4,'Gostei bastante, preço dentro do combinado.','2026-07-04 02:37:21'),(95,47,29,3,'Resolveu o problema, porém precisou voltar uma segunda vez.','2026-07-31 02:37:21'),(96,53,29,3,'Resolveu o problema, porém precisou voltar uma segunda vez.','2026-08-13 02:37:21'),(97,57,29,4,'Gostei bastante, preço dentro do combinado.','2026-04-21 02:37:21'),(98,43,30,3,'Atendimento razoável, esperava um pouco mais.','2026-05-28 02:37:21'),(99,44,30,4,'Gostei bastante, preço dentro do combinado.','2026-10-08 02:37:21'),(100,54,30,3,'Serviço ok, mas demorou mais do que o combinado.','2026-07-15 02:37:21'),(101,56,30,3,'Atendimento razoável, esperava um pouco mais.','2026-08-08 02:37:21'),(102,57,30,4,'Trabalho bem feito, poderia ter limpado melhor depois.','2026-07-21 02:37:21'),(103,60,30,3,'Atendimento razoável, esperava um pouco mais.','2026-09-06 02:37:21'),(104,65,30,5,'Muito profissional, pontual e caprichoso.','2026-05-24 02:37:21'),(105,54,31,4,'Bom serviço, só atrasou um pouco para chegar.','2026-04-18 02:37:21'),(106,58,32,4,'Atencioso e organizado, recomendo.','2026-05-14 02:37:21'),(107,45,33,5,'Superou as expectativas, voltarei a contratar com certeza.','2026-06-03 02:37:21'),(108,53,33,5,'Atendimento excelente do começo ao fim. Já indiquei para a família.','2026-08-05 02:37:21'),(109,59,33,5,'Atendimento excelente do começo ao fim. Já indiquei para a família.','2026-08-07 02:37:21'),(110,60,33,4,'Bom serviço, só atrasou um pouco para chegar.','2026-07-04 02:37:21'),(111,66,33,5,'Superou as expectativas, voltarei a contratar com certeza.','2026-09-25 02:37:21'),(112,44,34,4,'Atencioso e organizado, recomendo.','2026-05-04 02:37:21'),(113,45,34,4,'Atencioso e organizado, recomendo.','2026-08-30 02:37:21'),(114,54,34,5,'Superou as expectativas, voltarei a contratar com certeza.','2026-04-20 02:37:21'),(115,58,34,3,'Resolveu o problema, porém precisou voltar uma segunda vez.','2026-09-22 02:37:21'),(116,66,34,5,'Resolveu tudo rapidamente e com preço justo.','2026-06-05 02:37:21'),(117,67,34,3,'Serviço ok, mas demorou mais do que o combinado.','2026-05-09 02:37:21'),(118,45,35,3,'Resolveu o problema, porém precisou voltar uma segunda vez.','2026-06-04 02:37:21'),(119,49,35,3,'Resolveu o problema, porém precisou voltar uma segunda vez.','2026-08-11 02:37:21'),(120,54,35,4,'Trabalho bem feito, poderia ter limpado melhor depois.','2026-07-13 02:37:21'),(121,56,35,4,'Gostei bastante, preço dentro do combinado.','2026-06-12 02:37:21'),(122,66,35,3,'Atendimento razoável, esperava um pouco mais.','2026-09-06 02:37:21'),(123,45,36,4,'Bom serviço, só atrasou um pouco para chegar.','2026-05-06 02:37:21'),(124,47,36,4,'Bom serviço, só atrasou um pouco para chegar.','2026-06-30 02:37:21'),(125,49,36,5,'Superou as expectativas, voltarei a contratar com certeza.','2026-06-13 02:37:21'),(126,62,36,4,'Gostei bastante, preço dentro do combinado.','2026-04-23 02:37:21'),(127,64,36,5,'Superou as expectativas, voltarei a contratar com certeza.','2026-05-17 02:37:21'),(128,47,37,5,'Superou as expectativas, voltarei a contratar com certeza.','2026-10-04 02:37:21'),(129,43,38,4,'Atencioso e organizado, recomendo.','2026-08-06 02:37:21'),(130,54,38,5,'Superou as expectativas, voltarei a contratar com certeza.','2026-09-17 02:37:21'),(131,61,38,5,'Muito profissional, pontual e caprichoso.','2026-09-11 02:37:21'),(132,63,38,5,'Muito profissional, pontual e caprichoso.','2026-05-21 02:37:21'),(133,65,38,5,'Atendimento excelente do começo ao fim. Já indiquei para a família.','2026-08-05 02:37:21'),(134,51,39,5,'Serviço impecável, recomendo de olhos fechados!','2026-09-17 02:37:21'),(135,53,39,4,'Trabalho bem feito, poderia ter limpado melhor depois.','2026-07-07 02:37:21'),(136,55,39,4,'Atencioso e organizado, recomendo.','2026-08-26 02:37:21'),(137,57,39,5,'Resolveu tudo rapidamente e com preço justo.','2026-06-12 02:37:21'),(138,62,39,5,'Resolveu tudo rapidamente e com preço justo.','2026-04-27 02:37:21'),(139,46,40,5,'Muito profissional, pontual e caprichoso.','2026-08-27 02:37:21'),(140,1,41,4,'Atencioso e organizado, recomendo.','2026-06-14 02:37:21'),(141,53,41,3,'Serviço ok, mas demorou mais do que o combinado.','2026-05-20 02:37:21'),(142,54,42,4,'Trabalho bem feito, poderia ter limpado melhor depois.','2026-07-25 02:37:21'),(143,57,42,4,'Bom serviço, só atrasou um pouco para chegar.','2026-07-04 02:37:21'),(144,61,42,5,'Superou as expectativas, voltarei a contratar com certeza.','2026-08-29 02:37:21');
/*!40000 ALTER TABLE `avaliacoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `buscas`
--

DROP TABLE IF EXISTS `buscas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buscas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `categoria_id` int(10) unsigned DEFAULT NULL,
  `termo` varchar(100) DEFAULT NULL,
  `resultados` int(10) unsigned NOT NULL DEFAULT 0,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_buscas_data` (`criado_em`),
  KEY `idx_buscas_categoria` (`categoria_id`),
  CONSTRAINT `fk_busca_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=514 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buscas`
--

LOCK TABLES `buscas` WRITE;
/*!40000 ALTER TABLE `buscas` DISABLE KEYS */;
INSERT INTO `buscas` VALUES (1,1,NULL,1,'2026-10-15 16:01:39'),(2,1,NULL,2,'2026-09-04 23:41:39'),(3,1,NULL,3,'2026-09-25 07:21:39'),(4,4,NULL,4,'2026-10-15 15:01:39'),(5,1,NULL,2,'2026-09-08 15:08:39'),(6,1,NULL,3,'2026-09-27 22:48:39'),(7,4,NULL,4,'2026-08-19 06:28:39'),(8,4,NULL,5,'2026-09-08 14:08:39'),(9,1,NULL,3,'2026-10-01 14:15:39'),(10,4,NULL,4,'2026-08-21 21:55:39'),(11,4,NULL,5,'2026-09-11 05:35:39'),(12,3,NULL,6,'2026-10-01 13:15:39'),(13,4,NULL,4,'2026-08-25 13:22:39'),(14,4,NULL,5,'2026-09-13 21:02:39'),(15,3,NULL,6,'2026-10-04 04:42:39'),(16,5,NULL,7,'2026-08-25 12:22:39'),(17,4,NULL,5,'2026-09-17 12:29:39'),(18,3,NULL,6,'2026-10-06 20:09:39'),(19,5,NULL,7,'2026-08-28 03:49:39'),(20,6,NULL,8,'2026-09-17 11:29:39'),(21,3,NULL,6,'2026-10-10 11:36:39'),(22,5,NULL,7,'2026-08-30 19:16:39'),(23,6,NULL,8,'2026-09-20 02:56:39'),(24,2,NULL,9,'2026-10-10 10:36:39'),(25,5,NULL,7,'2026-09-03 10:43:39'),(26,6,NULL,8,'2026-09-22 18:23:39'),(27,2,NULL,9,'2026-10-13 02:03:39'),(28,7,NULL,1,'2026-09-03 09:43:39'),(29,6,NULL,8,'2026-09-26 09:50:39'),(30,2,NULL,9,'2026-08-16 17:30:39'),(31,7,NULL,1,'2026-09-06 01:10:39'),(32,NULL,'aula de inglês',2,'2026-09-26 08:50:39'),(33,2,NULL,9,'2026-08-20 08:57:39'),(34,7,NULL,1,'2026-09-08 16:37:39'),(35,NULL,'pintor',2,'2026-09-29 00:17:39'),(36,1,NULL,3,'2026-08-20 07:57:39'),(37,7,NULL,1,'2026-09-12 08:04:39'),(38,NULL,'manicure',2,'2026-10-02 15:44:39'),(39,1,NULL,3,'2026-08-22 23:24:39'),(40,1,NULL,4,'2026-09-12 07:04:39'),(41,NULL,'eletricista',2,'2026-10-05 07:11:39'),(42,1,NULL,3,'2026-08-26 14:51:39'),(43,1,NULL,4,'2026-09-14 22:31:39'),(44,1,NULL,5,'2026-10-05 06:11:39'),(45,1,NULL,3,'2026-08-29 06:18:39'),(46,1,NULL,4,'2026-09-18 13:58:39'),(47,1,NULL,5,'2026-10-07 21:38:39'),(48,4,NULL,6,'2026-08-29 05:18:39'),(49,1,NULL,4,'2026-09-21 05:25:39'),(50,1,NULL,5,'2026-10-11 13:05:39'),(51,4,NULL,6,'2026-08-31 20:45:39'),(52,4,NULL,7,'2026-09-21 04:25:39'),(53,1,NULL,5,'2026-10-14 04:32:39'),(54,4,NULL,6,'2026-09-04 12:12:39'),(55,4,NULL,7,'2026-09-23 19:52:39'),(56,3,NULL,8,'2026-10-14 03:32:39'),(57,4,NULL,6,'2026-09-07 03:39:39'),(58,4,NULL,7,'2026-09-27 11:19:39'),(59,3,NULL,8,'2026-08-17 18:59:39'),(60,5,NULL,9,'2026-09-07 02:39:39'),(61,4,NULL,7,'2026-09-30 02:46:39'),(62,3,NULL,8,'2026-08-21 10:26:39'),(63,5,NULL,9,'2026-09-09 18:06:39'),(64,6,NULL,1,'2026-09-30 01:46:39'),(65,3,NULL,8,'2026-08-24 01:53:39'),(66,5,NULL,9,'2026-09-13 09:33:39'),(67,6,NULL,1,'2026-10-02 17:13:39'),(68,2,NULL,2,'2026-08-24 00:53:39'),(69,5,NULL,9,'2026-09-16 01:00:39'),(70,6,NULL,1,'2026-10-06 08:40:39'),(71,2,NULL,2,'2026-08-26 16:20:39'),(72,7,NULL,3,'2026-09-16 00:00:39'),(73,6,NULL,1,'2026-10-09 00:07:39'),(74,2,NULL,2,'2026-08-30 07:47:39'),(75,7,NULL,3,'2026-09-19 15:27:39'),(76,NULL,'pintor',4,'2026-10-08 23:07:39'),(77,2,NULL,2,'2026-09-01 23:14:39'),(78,7,NULL,3,'2026-09-22 06:54:39'),(79,NULL,'manicure',4,'2026-10-12 14:34:39'),(80,1,NULL,5,'2026-09-01 22:14:39'),(81,7,NULL,3,'2026-09-24 22:21:39'),(82,NULL,'eletricista',4,'2026-10-15 06:01:39'),(83,1,NULL,5,'2026-09-05 13:41:39'),(84,1,NULL,6,'2026-09-24 21:21:39'),(85,NULL,'diarista',4,'2026-08-18 21:28:39'),(86,1,NULL,5,'2026-09-08 05:08:39'),(87,1,NULL,6,'2026-09-28 12:48:39'),(88,1,NULL,7,'2026-08-18 20:28:39'),(89,1,NULL,5,'2026-09-10 20:35:39'),(90,1,NULL,6,'2026-10-01 04:15:39'),(91,1,NULL,7,'2026-08-22 11:55:39'),(92,4,NULL,8,'2026-09-10 19:35:39'),(93,1,NULL,6,'2026-10-03 19:42:39'),(94,1,NULL,7,'2026-08-25 03:22:39'),(95,4,NULL,8,'2026-09-14 11:02:39'),(96,4,NULL,9,'2026-10-03 18:42:39'),(97,1,NULL,7,'2026-08-27 18:49:39'),(98,4,NULL,8,'2026-09-17 02:29:39'),(99,4,NULL,9,'2026-10-07 10:09:39'),(100,3,NULL,1,'2026-08-27 17:49:39'),(101,4,NULL,8,'2026-09-19 17:56:39'),(102,4,NULL,9,'2026-10-10 01:36:39'),(103,3,NULL,1,'2026-08-31 09:16:39'),(104,5,NULL,2,'2026-09-19 16:56:39'),(105,4,NULL,9,'2026-10-12 17:03:39'),(106,3,NULL,1,'2026-09-03 00:43:39'),(107,5,NULL,2,'2026-09-23 08:23:39'),(108,6,NULL,3,'2026-10-12 16:03:39'),(109,3,NULL,1,'2026-09-05 16:10:39'),(110,5,NULL,2,'2026-09-25 23:50:39'),(111,6,NULL,3,'2026-08-17 07:30:39'),(112,2,NULL,4,'2026-09-06 15:10:39'),(113,5,NULL,2,'2026-09-29 15:17:39'),(114,6,NULL,3,'2026-08-19 22:57:39'),(115,2,NULL,4,'2026-09-09 06:37:39'),(116,7,NULL,5,'2026-09-29 14:17:39'),(117,6,NULL,3,'2026-08-23 14:24:39'),(118,2,NULL,4,'2026-09-11 22:04:39'),(119,7,NULL,5,'2026-10-02 05:44:39'),(120,NULL,'manicure',6,'2026-08-23 13:24:39'),(121,2,NULL,4,'2026-09-15 13:31:39'),(122,7,NULL,5,'2026-10-04 21:11:39'),(123,NULL,'eletricista',6,'2026-08-26 04:51:39'),(124,1,NULL,7,'2026-09-15 12:31:39'),(125,7,NULL,5,'2026-10-08 12:38:39'),(126,NULL,'diarista',6,'2026-08-28 20:18:39'),(127,1,NULL,7,'2026-09-18 03:58:39'),(128,1,NULL,8,'2026-10-08 11:38:39'),(129,NULL,'aula de inglês',6,'2026-09-01 11:45:39'),(130,1,NULL,7,'2026-09-20 19:25:39'),(131,1,NULL,8,'2026-10-11 03:05:39'),(132,1,NULL,9,'2026-09-01 10:45:39'),(133,1,NULL,7,'2026-09-24 10:52:39'),(134,1,NULL,8,'2026-10-13 18:32:39'),(135,1,NULL,9,'2026-09-04 02:12:39'),(136,4,NULL,1,'2026-09-24 09:52:39'),(137,1,NULL,8,'2026-08-18 09:59:39'),(138,1,NULL,9,'2026-09-06 17:39:39'),(139,4,NULL,1,'2026-09-27 01:19:39'),(140,4,NULL,2,'2026-08-18 08:59:39'),(141,1,NULL,9,'2026-09-10 09:06:39'),(142,4,NULL,1,'2026-09-29 16:46:39'),(143,4,NULL,2,'2026-08-21 00:26:39'),(144,3,NULL,3,'2026-09-10 08:06:39'),(145,4,NULL,1,'2026-10-03 08:13:39'),(146,4,NULL,2,'2026-08-24 15:53:39'),(147,3,NULL,3,'2026-09-12 23:33:39'),(148,5,NULL,4,'2026-10-03 07:13:39'),(149,4,NULL,2,'2026-08-27 07:20:39'),(150,3,NULL,3,'2026-09-16 15:00:39'),(151,5,NULL,4,'2026-10-05 22:40:39'),(152,6,NULL,5,'2026-08-27 06:20:39'),(153,3,NULL,3,'2026-09-19 06:27:39'),(154,5,NULL,4,'2026-10-09 14:07:39'),(155,6,NULL,5,'2026-08-29 21:47:39'),(156,2,NULL,6,'2026-09-19 05:27:39'),(157,5,NULL,4,'2026-10-12 05:34:39'),(158,6,NULL,5,'2026-09-02 13:14:39'),(159,2,NULL,6,'2026-09-21 20:54:39'),(160,7,NULL,7,'2026-10-12 04:34:39'),(161,6,NULL,5,'2026-09-05 04:41:39'),(162,2,NULL,6,'2026-09-25 12:21:39'),(163,7,NULL,7,'2026-10-14 20:01:39'),(164,NULL,'eletricista',8,'2026-09-05 03:41:39'),(165,2,NULL,6,'2026-09-28 03:48:39'),(166,7,NULL,7,'2026-08-19 11:28:39'),(167,NULL,'diarista',8,'2026-09-07 19:08:39'),(168,1,NULL,9,'2026-09-28 02:48:39'),(169,7,NULL,7,'2026-08-22 02:55:39'),(170,NULL,'aula de inglês',8,'2026-09-11 10:35:39'),(171,1,NULL,9,'2026-09-30 18:15:39'),(172,1,NULL,1,'2026-08-22 01:55:39'),(173,NULL,'pintor',8,'2026-09-14 02:02:39'),(174,1,NULL,9,'2026-10-04 09:42:39'),(175,1,NULL,1,'2026-08-24 17:22:39'),(176,1,NULL,2,'2026-09-14 01:02:39'),(177,1,NULL,9,'2026-10-07 01:09:39'),(178,1,NULL,1,'2026-08-28 08:49:39'),(179,1,NULL,2,'2026-09-16 16:29:39'),(180,4,NULL,3,'2026-10-07 00:09:39'),(181,1,NULL,1,'2026-08-31 00:16:39'),(182,1,NULL,2,'2026-09-20 07:56:39'),(183,4,NULL,3,'2026-10-10 15:36:39'),(184,4,NULL,4,'2026-08-30 23:16:39'),(185,1,NULL,2,'2026-09-22 23:23:39'),(186,4,NULL,3,'2026-10-13 07:03:39'),(187,4,NULL,4,'2026-09-03 14:43:39'),(188,3,NULL,5,'2026-09-22 22:23:39'),(189,4,NULL,3,'2026-08-16 22:30:39'),(190,4,NULL,4,'2026-09-06 06:10:39'),(191,3,NULL,5,'2026-09-26 13:50:39'),(192,5,NULL,6,'2026-08-16 21:30:39'),(193,4,NULL,4,'2026-09-08 21:37:39'),(194,3,NULL,5,'2026-09-29 05:17:39'),(195,5,NULL,6,'2026-08-20 12:57:39'),(196,6,NULL,7,'2026-09-08 20:37:39'),(197,3,NULL,5,'2026-10-01 20:44:39'),(198,5,NULL,6,'2026-08-23 04:24:39'),(199,6,NULL,7,'2026-09-12 12:04:39'),(200,2,NULL,8,'2026-10-01 19:44:39'),(201,5,NULL,6,'2026-08-25 19:51:39'),(202,6,NULL,7,'2026-09-15 03:31:39'),(203,2,NULL,8,'2026-10-05 11:11:39'),(204,7,NULL,9,'2026-08-25 18:51:39'),(205,6,NULL,7,'2026-09-17 18:58:39'),(206,2,NULL,8,'2026-10-08 02:38:39'),(207,7,NULL,9,'2026-08-29 10:18:39'),(208,NULL,'diarista',1,'2026-09-17 17:58:39'),(209,2,NULL,8,'2026-10-10 18:05:39'),(210,7,NULL,9,'2026-09-01 01:45:39'),(211,NULL,'aula de inglês',1,'2026-09-21 09:25:39'),(212,1,NULL,2,'2026-10-10 17:05:39'),(213,7,NULL,9,'2026-09-03 17:12:39'),(214,NULL,'pintor',1,'2026-09-24 00:52:39'),(215,1,NULL,2,'2026-10-14 08:32:39'),(216,1,NULL,3,'2026-09-03 16:12:39'),(217,NULL,'manicure',1,'2026-09-26 16:19:39'),(218,1,NULL,2,'2026-08-17 23:59:39'),(219,1,NULL,3,'2026-09-07 07:39:39'),(220,1,NULL,4,'2026-09-27 15:19:39'),(221,1,NULL,2,'2026-08-21 15:26:39'),(222,1,NULL,3,'2026-09-09 23:06:39'),(223,1,NULL,4,'2026-09-30 06:46:39'),(224,4,NULL,5,'2026-08-21 14:26:39'),(225,1,NULL,3,'2026-09-13 14:33:39'),(226,1,NULL,4,'2026-10-02 22:13:39'),(227,4,NULL,5,'2026-08-24 05:53:39'),(228,4,NULL,6,'2026-09-13 13:33:39'),(229,1,NULL,4,'2026-10-06 13:40:39'),(230,4,NULL,5,'2026-08-26 21:20:39'),(231,4,NULL,6,'2026-09-16 05:00:39'),(232,3,NULL,7,'2026-10-06 12:40:39'),(233,4,NULL,5,'2026-08-30 12:47:39'),(234,4,NULL,6,'2026-09-18 20:27:39'),(235,3,NULL,7,'2026-10-09 04:07:39'),(236,5,NULL,8,'2026-08-30 11:47:39'),(237,4,NULL,6,'2026-09-22 11:54:39'),(238,3,NULL,7,'2026-10-11 19:34:39'),(239,5,NULL,8,'2026-09-02 03:14:39'),(240,6,NULL,9,'2026-09-22 10:54:39'),(241,3,NULL,7,'2026-10-15 11:01:39'),(242,5,NULL,8,'2026-09-04 18:41:39'),(243,6,NULL,9,'2026-09-25 02:21:39'),(244,2,NULL,1,'2026-10-15 10:01:39'),(245,5,NULL,8,'2026-09-08 10:08:39'),(246,6,NULL,9,'2026-09-27 17:48:39'),(247,2,NULL,1,'2026-08-19 01:28:39'),(248,7,NULL,2,'2026-09-08 09:08:39'),(249,6,NULL,9,'2026-10-01 09:15:39'),(250,2,NULL,1,'2026-08-21 16:55:39'),(251,7,NULL,2,'2026-09-11 00:35:39'),(252,NULL,'aula de inglês',3,'2026-10-01 08:15:39'),(253,2,NULL,1,'2026-08-25 08:22:39'),(254,7,NULL,2,'2026-09-13 16:02:39'),(255,NULL,'pintor',3,'2026-10-03 23:42:39'),(256,1,NULL,4,'2026-08-25 07:22:39'),(257,7,NULL,2,'2026-09-17 07:29:39'),(258,NULL,'manicure',3,'2026-10-07 15:09:39'),(259,1,NULL,4,'2026-08-27 22:49:39'),(260,1,NULL,5,'2026-09-17 06:29:39'),(261,NULL,'eletricista',3,'2026-10-10 06:36:39'),(262,1,NULL,4,'2026-08-31 14:16:39'),(263,1,NULL,5,'2026-09-19 21:56:39'),(264,1,NULL,6,'2026-10-10 05:36:39'),(265,1,NULL,4,'2026-09-03 05:43:39'),(266,1,NULL,5,'2026-09-23 13:23:39'),(267,1,NULL,6,'2026-10-12 21:03:39'),(268,4,NULL,7,'2026-09-03 04:43:39'),(269,1,NULL,5,'2026-09-26 04:50:39'),(270,1,NULL,6,'2026-08-17 12:30:39'),(271,4,NULL,7,'2026-09-05 20:10:39'),(272,4,NULL,8,'2026-09-26 03:50:39'),(273,1,NULL,6,'2026-08-20 03:57:39'),(274,4,NULL,7,'2026-09-09 11:37:39'),(275,4,NULL,8,'2026-09-28 19:17:39'),(276,3,NULL,9,'2026-08-20 02:57:39'),(277,4,NULL,7,'2026-09-12 03:04:39'),(278,4,NULL,8,'2026-10-02 10:44:39'),(279,3,NULL,9,'2026-08-22 18:24:39'),(280,5,NULL,1,'2026-09-12 02:04:39'),(281,4,NULL,8,'2026-10-05 02:11:39'),(282,3,NULL,9,'2026-08-26 09:51:39'),(283,5,NULL,1,'2026-09-14 17:31:39'),(284,6,NULL,2,'2026-10-05 01:11:39'),(285,3,NULL,9,'2026-08-29 01:18:39'),(286,5,NULL,1,'2026-09-18 08:58:39'),(287,6,NULL,2,'2026-10-07 16:38:39'),(288,2,NULL,3,'2026-08-29 00:18:39'),(289,5,NULL,1,'2026-09-21 00:25:39'),(290,6,NULL,2,'2026-10-11 08:05:39'),(291,2,NULL,3,'2026-09-01 15:45:39'),(292,7,NULL,4,'2026-09-20 23:25:39'),(293,6,NULL,2,'2026-10-13 23:32:39'),(294,2,NULL,3,'2026-09-04 07:12:39'),(295,7,NULL,4,'2026-09-24 14:52:39'),(296,NULL,'pintor',5,'2026-10-13 22:32:39'),(297,2,NULL,3,'2026-09-06 22:39:39'),(298,7,NULL,4,'2026-09-27 06:19:39'),(299,NULL,'manicure',5,'2026-08-18 13:59:39'),(300,1,NULL,6,'2026-09-06 21:39:39'),(301,7,NULL,4,'2026-09-29 21:46:39'),(302,NULL,'eletricista',5,'2026-08-21 05:26:39'),(303,1,NULL,6,'2026-09-10 13:06:39'),(304,1,NULL,7,'2026-09-29 20:46:39'),(305,NULL,'diarista',5,'2026-08-23 20:53:39'),(306,1,NULL,6,'2026-09-13 04:33:39'),(307,1,NULL,7,'2026-10-03 12:13:39'),(308,1,NULL,8,'2026-08-23 19:53:39'),(309,1,NULL,6,'2026-09-15 20:00:39'),(310,1,NULL,7,'2026-10-06 03:40:39'),(311,1,NULL,8,'2026-08-27 11:20:39'),(312,4,NULL,9,'2026-09-15 19:00:39'),(313,1,NULL,7,'2026-10-08 19:07:39'),(314,1,NULL,8,'2026-08-30 02:47:39'),(315,4,NULL,9,'2026-09-19 10:27:39'),(316,4,NULL,1,'2026-10-08 18:07:39'),(317,1,NULL,8,'2026-09-01 18:14:39'),(318,4,NULL,9,'2026-09-22 01:54:39'),(319,4,NULL,1,'2026-10-12 09:34:39'),(320,3,NULL,2,'2026-09-01 17:14:39'),(321,4,NULL,9,'2026-09-24 17:21:39'),(322,4,NULL,1,'2026-10-15 01:01:39'),(323,3,NULL,2,'2026-09-05 08:41:39'),(324,5,NULL,3,'2026-09-24 16:21:39'),(325,4,NULL,1,'2026-08-18 16:28:39'),(326,3,NULL,2,'2026-09-08 00:08:39'),(327,5,NULL,3,'2026-09-28 07:48:39'),(328,6,NULL,4,'2026-08-19 15:28:39'),(329,3,NULL,2,'2026-09-11 15:35:39'),(330,5,NULL,3,'2026-09-30 23:15:39'),(331,6,NULL,4,'2026-08-22 06:55:39'),(332,2,NULL,5,'2026-09-11 14:35:39'),(333,5,NULL,3,'2026-10-04 14:42:39'),(334,6,NULL,4,'2026-08-24 22:22:39'),(335,2,NULL,5,'2026-09-14 06:02:39'),(336,7,NULL,6,'2026-10-04 13:42:39'),(337,6,NULL,4,'2026-08-28 13:49:39'),(338,2,NULL,5,'2026-09-16 21:29:39'),(339,7,NULL,6,'2026-10-07 05:09:39'),(340,NULL,'manicure',7,'2026-08-28 12:49:39'),(341,2,NULL,5,'2026-09-20 12:56:39'),(342,7,NULL,6,'2026-10-09 20:36:39'),(343,NULL,'eletricista',7,'2026-08-31 04:16:39'),(344,1,NULL,8,'2026-09-20 11:56:39'),(345,7,NULL,6,'2026-10-13 12:03:39'),(346,NULL,'diarista',7,'2026-09-02 19:43:39'),(347,1,NULL,8,'2026-09-23 03:23:39'),(348,1,NULL,9,'2026-10-13 11:03:39'),(349,NULL,'aula de inglês',7,'2026-09-06 11:10:39'),(350,1,NULL,8,'2026-09-25 18:50:39'),(351,1,NULL,9,'2026-08-17 02:30:39'),(352,1,NULL,1,'2026-09-06 10:10:39'),(353,1,NULL,8,'2026-09-29 10:17:39'),(354,1,NULL,9,'2026-08-19 17:57:39'),(355,1,NULL,1,'2026-09-09 01:37:39'),(356,4,NULL,2,'2026-09-29 09:17:39'),(357,1,NULL,9,'2026-08-23 09:24:39'),(358,1,NULL,1,'2026-09-11 17:04:39'),(359,4,NULL,2,'2026-10-02 00:44:39'),(360,4,NULL,3,'2026-08-23 08:24:39'),(361,1,NULL,1,'2026-09-15 08:31:39'),(362,4,NULL,2,'2026-10-04 16:11:39'),(363,4,NULL,3,'2026-08-25 23:51:39'),(364,3,NULL,4,'2026-09-15 07:31:39'),(365,4,NULL,2,'2026-10-08 07:38:39'),(366,4,NULL,3,'2026-08-29 15:18:39'),(367,3,NULL,4,'2026-09-17 22:58:39'),(368,5,NULL,5,'2026-10-08 06:38:39'),(369,4,NULL,3,'2026-09-01 06:45:39'),(370,3,NULL,4,'2026-09-21 14:25:39'),(371,5,NULL,5,'2026-10-10 22:05:39'),(372,6,NULL,6,'2026-09-01 05:45:39'),(373,3,NULL,4,'2026-09-24 05:52:39'),(374,5,NULL,5,'2026-10-14 13:32:39'),(375,6,NULL,6,'2026-09-03 21:12:39'),(376,2,NULL,7,'2026-09-24 04:52:39'),(377,5,NULL,5,'2026-08-18 04:59:39'),(378,6,NULL,6,'2026-09-07 12:39:39'),(379,2,NULL,7,'2026-09-26 20:19:39'),(380,7,NULL,8,'2026-08-18 03:59:39'),(381,6,NULL,6,'2026-09-10 04:06:39'),(382,2,NULL,7,'2026-09-30 11:46:39'),(383,7,NULL,8,'2026-08-20 19:26:39'),(384,NULL,'eletricista',9,'2026-09-10 03:06:39'),(385,2,NULL,7,'2026-10-03 03:13:39'),(386,7,NULL,8,'2026-08-24 10:53:39'),(387,NULL,'diarista',9,'2026-09-12 18:33:39'),(388,1,NULL,1,'2026-10-03 02:13:39'),(389,7,NULL,8,'2026-08-27 02:20:39'),(390,NULL,'aula de inglês',9,'2026-09-16 10:00:39'),(391,1,NULL,1,'2026-10-05 17:40:39'),(392,1,NULL,2,'2026-08-27 01:20:39'),(393,NULL,'pintor',9,'2026-09-19 01:27:39'),(394,1,NULL,1,'2026-10-09 09:07:39'),(395,1,NULL,2,'2026-08-29 16:47:39'),(396,1,NULL,3,'2026-09-19 00:27:39'),(397,1,NULL,1,'2026-10-12 00:34:39'),(398,1,NULL,2,'2026-09-02 08:14:39'),(399,1,NULL,3,'2026-09-22 15:54:39'),(400,4,NULL,4,'2026-10-11 23:34:39'),(512,NULL,'eletricista',2,'2026-10-15 16:05:06'),(513,1,NULL,7,'2026-10-15 16:05:07');
/*!40000 ALTER TABLE `buscas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(60) NOT NULL,
  `slug` varchar(60) NOT NULL,
  `icone` varchar(40) NOT NULL,
  `descricao` varchar(160) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_categorias_slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES (1,'Reparos e manutenção','reparos','fa-screwdriver-wrench','Eletricistas, encanadores e consertos em geral'),(2,'Reformas e construção','reformas','fa-trowel-bricks','Pedreiros, pintores e acabamento'),(3,'Limpeza','limpeza','fa-broom','Diaristas, faxinas e limpeza pós-obra'),(4,'Tecnologia','tecnologia','fa-laptop-code','Suporte técnico, redes e desenvolvimento'),(5,'Aulas e cursos','aulas','fa-graduation-cap','Reforço escolar, idiomas e música'),(6,'Beleza e bem-estar','beleza','fa-spa','Cabelo, maquiagem, estética e personal'),(7,'Eventos','eventos','fa-champagne-glasses','Fotografia, buffet, decoração e DJ'),(8,'Automotivo','automotivo','fa-car','Mecânica, funilaria e lavagem');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contatos`
--

DROP TABLE IF EXISTS `contatos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contatos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(120) NOT NULL,
  `email` varchar(150) NOT NULL,
  `telefone` varchar(11) DEFAULT NULL,
  `assunto` enum('duvida','problema','sugestao','parceria','outro') NOT NULL,
  `mensagem` text NOT NULL,
  `status` enum('novo','lido','respondido') NOT NULL DEFAULT 'novo',
  `resposta` text DEFAULT NULL,
  `respondido_em` datetime DEFAULT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_contatos_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contatos`
--

LOCK TABLES `contatos` WRITE;
/*!40000 ALTER TABLE `contatos` DISABLE KEYS */;
INSERT INTO `contatos` VALUES (1,'Visitante Teste','visitante@teste.com',NULL,'duvida','Como faço para aparecer nas buscas de outra cidade?','lido',NULL,NULL,'2026-10-15 00:37:21'),(2,'Roberta Lima','roberta@teste.com','18991112222','problema','Não consigo alterar minha foto de perfil, aparece um erro.','lido',NULL,NULL,'2026-10-14 02:37:21'),(3,'Marcos Vieira','marcos@teste.com',NULL,'parceria','Tenho uma loja de materiais de construção e gostaria de anunciar no site.','lido',NULL,NULL,'2026-10-12 02:37:21'),(4,'Clara Duarte','clara@teste.com',NULL,'sugestao','Seria ótimo poder salvar profissionais favoritos.','respondido','Olá, Clara! Obrigado pela sugestão, ela já está na nossa lista de melhorias.','2026-10-10 23:37:21','2026-10-10 02:37:21');
/*!40000 ALTER TABLE `contatos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversas`
--

DROP TABLE IF EXISTS `conversas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conversas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cliente_id` int(10) unsigned NOT NULL,
  `prestador_id` int(10) unsigned NOT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_conversa` (`cliente_id`,`prestador_id`),
  KEY `idx_conversas_prestador` (`prestador_id`),
  CONSTRAINT `fk_conversa_cliente` FOREIGN KEY (`cliente_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_conversa_prestador` FOREIGN KEY (`prestador_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversas`
--

LOCK TABLES `conversas` WRITE;
/*!40000 ALTER TABLE `conversas` DISABLE KEYS */;
INSERT INTO `conversas` VALUES (1,1,3,'2026-09-26 01:37:21'),(2,1,4,'2026-09-30 01:37:21'),(3,1,5,'2026-10-13 01:37:21'),(4,43,2,'2026-10-02 01:37:21'),(5,44,2,'2026-10-04 01:37:21'),(6,45,2,'2026-10-07 01:37:21'),(7,66,33,'2026-09-28 01:37:21'),(8,59,15,'2026-10-08 01:37:21'),(9,44,14,'2026-10-11 01:37:21'),(10,45,36,'2026-10-12 01:37:21'),(11,43,30,'2026-10-05 01:37:21'),(12,64,4,'2026-10-12 01:37:21'),(13,44,9,'2026-10-04 01:37:21'),(14,54,9,'2026-10-04 01:37:21'),(15,63,10,'2026-10-14 01:37:21'),(16,61,32,'2026-10-08 01:37:21'),(17,58,6,'2026-10-03 01:37:21');
/*!40000 ALTER TABLE `conversas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `denuncias`
--

DROP TABLE IF EXISTS `denuncias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `denuncias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `denunciante_id` int(10) unsigned NOT NULL,
  `prestador_id` int(10) unsigned DEFAULT NULL,
  `avaliacao_id` int(10) unsigned DEFAULT NULL,
  `motivo` enum('spam','ofensivo','falso','golpe','outro') NOT NULL,
  `detalhes` varchar(500) DEFAULT NULL,
  `status` enum('aberta','resolvida','descartada') NOT NULL DEFAULT 'aberta',
  `resolvido_em` datetime DEFAULT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_denuncias_status` (`status`,`criado_em`),
  KEY `idx_denuncias_prestador` (`prestador_id`),
  KEY `idx_denuncias_avaliacao` (`avaliacao_id`),
  KEY `fk_denuncia_denunciante` (`denunciante_id`),
  CONSTRAINT `fk_denuncia_avaliacao` FOREIGN KEY (`avaliacao_id`) REFERENCES `avaliacoes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_denuncia_denunciante` FOREIGN KEY (`denunciante_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_denuncia_prestador` FOREIGN KEY (`prestador_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `denuncias`
--

LOCK TABLES `denuncias` WRITE;
/*!40000 ALTER TABLE `denuncias` DISABLE KEYS */;
INSERT INTO `denuncias` VALUES (1,1,NULL,5,'ofensivo','O comentário usa palavras ofensivas.','aberta',NULL,'2026-10-14 16:01:39'),(2,5,NULL,10,'falso','Nunca prestei serviço para essa pessoa.','aberta',NULL,'2026-10-15 13:01:39'),(3,44,8,NULL,'golpe','Pediu pagamento adiantado e não apareceu.','aberta',NULL,'2026-10-13 16:01:39'),(4,47,11,NULL,'spam','Perfil com divulgação repetida.','descartada','2026-10-10 13:01:39','2026-10-09 16:01:39'),(6,1,24,NULL,'outro','Teste teste teste','descartada','2026-10-15 13:10:58','2026-10-15 16:10:39');
/*!40000 ALTER TABLE `denuncias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geocode_cache`
--

DROP TABLE IF EXISTS `geocode_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geocode_cache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cidade` varchar(100) NOT NULL,
  `estado` char(2) NOT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_geocode_cidade` (`cidade`,`estado`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geocode_cache`
--

LOCK TABLES `geocode_cache` WRITE;
/*!40000 ALTER TABLE `geocode_cache` DISABLE KEYS */;
INSERT INTO `geocode_cache` VALUES (1,'Presidente Prudente','SP',-22.12560000,-51.38890000,'2026-10-15 02:37:21'),(2,'Álvares Machado','SP',-22.07640000,-51.47220000,'2026-10-15 02:37:21'),(3,'Regente Feijó','SP',-22.22140000,-51.30280000,'2026-10-15 02:37:21'),(4,'Pirapozinho','SP',-22.27530000,-51.50000000,'2026-10-15 02:37:21'),(5,'Martinópolis','SP',-22.14580000,-51.17080000,'2026-10-15 02:37:21'),(6,'Presidente Venceslau','SP',-21.87610000,-51.84360000,'2026-10-15 02:37:21'),(7,'Presidente Epitácio','SP',-21.76330000,-52.11560000,'2026-10-15 02:37:21'),(8,'Santo Anastácio','SP',-21.97750000,-51.65220000,'2026-10-15 02:37:21'),(9,'Assis','SP',-22.66110000,-50.41220000,'2026-10-15 02:37:21'),(10,'Marília','SP',-22.21390000,-49.94580000,'2026-10-15 02:37:21'),(11,'São Paulo','SP',-23.55050000,-46.63330000,'2026-10-15 02:37:21'),(12,'Campinas','SP',-22.90560000,-47.06080000,'2026-10-15 02:37:21');
/*!40000 ALTER TABLE `geocode_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensagens`
--

DROP TABLE IF EXISTS `mensagens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mensagens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `conversa_id` int(10) unsigned NOT NULL,
  `remetente_id` int(10) unsigned NOT NULL,
  `conteudo` text NOT NULL,
  `lida` tinyint(1) NOT NULL DEFAULT 0,
  `enviada_em` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_mensagens_conversa` (`conversa_id`,`id`),
  KEY `fk_mensagem_remetente` (`remetente_id`),
  CONSTRAINT `fk_mensagem_conversa` FOREIGN KEY (`conversa_id`) REFERENCES `conversas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mensagem_remetente` FOREIGN KEY (`remetente_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensagens`
--

LOCK TABLES `mensagens` WRITE;
/*!40000 ALTER TABLE `mensagens` DISABLE KEYS */;
INSERT INTO `mensagens` VALUES (1,1,1,'Olá! Vi seu perfil aqui na Nexus. Você atende na minha região?',1,'2026-09-26 02:02:21'),(2,1,3,'Olá! Atendo sim. Do que você precisa?',1,'2026-09-26 02:09:21'),(3,1,1,'Preciso de um orçamento para esta semana. Qual seria o valor?',1,'2026-09-26 02:16:21'),(4,1,3,'Consigo passar aí amanhã para avaliar e já te passo o valor certinho.',1,'2026-09-26 02:23:21'),(5,1,1,'Perfeito, combinado!',0,'2026-09-26 02:30:21'),(6,2,1,'Boa tarde! Você tem horário disponível no sábado?',1,'2026-09-30 02:16:21'),(7,2,4,'Boa tarde! Tenho às 9h ou às 14h.',1,'2026-09-30 02:23:21'),(8,2,1,'Pode ser às 9h. Obrigado!',0,'2026-09-30 02:30:21'),(9,3,1,'Boa tarde! Você tem horário disponível no sábado?',1,'2026-10-13 02:16:21'),(10,3,5,'Boa tarde! Tenho às 9h ou às 14h.',1,'2026-10-13 02:23:21'),(11,3,1,'Pode ser às 9h. Obrigado!',0,'2026-10-13 02:30:21'),(12,4,43,'Oi, tudo bem? Quanto você cobra pelo serviço?',1,'2026-10-02 02:23:21'),(13,4,2,'Tudo ótimo! Depende do tamanho, mas costuma ficar dentro da faixa do meu perfil. Pode me mandar mais detalhes?',0,'2026-10-02 02:30:21'),(14,5,44,'Oi, tudo bem? Quanto você cobra pelo serviço?',1,'2026-10-04 02:23:21'),(15,5,2,'Tudo ótimo! Depende do tamanho, mas costuma ficar dentro da faixa do meu perfil. Pode me mandar mais detalhes?',0,'2026-10-04 02:30:21'),(16,6,45,'Oi, tudo bem? Quanto você cobra pelo serviço?',1,'2026-10-07 02:23:21'),(17,6,2,'Tudo ótimo! Depende do tamanho, mas costuma ficar dentro da faixa do meu perfil. Pode me mandar mais detalhes?',0,'2026-10-07 02:30:21'),(18,7,66,'Boa tarde! Você tem horário disponível no sábado?',1,'2026-09-28 02:16:21'),(19,7,33,'Boa tarde! Tenho às 9h ou às 14h.',1,'2026-09-28 02:23:21'),(20,7,66,'Pode ser às 9h. Obrigado!',0,'2026-09-28 02:30:21'),(21,8,59,'Oi, tudo bem? Quanto você cobra pelo serviço?',1,'2026-10-08 02:23:21'),(22,8,15,'Tudo ótimo! Depende do tamanho, mas costuma ficar dentro da faixa do meu perfil. Pode me mandar mais detalhes?',0,'2026-10-08 02:30:21'),(23,9,44,'Oi, tudo bem? Quanto você cobra pelo serviço?',1,'2026-10-11 02:23:21'),(24,9,14,'Tudo ótimo! Depende do tamanho, mas costuma ficar dentro da faixa do meu perfil. Pode me mandar mais detalhes?',0,'2026-10-11 02:30:21'),(25,10,45,'Olá! Vi seu perfil aqui na Nexus. Você atende na minha região?',1,'2026-10-12 02:02:21'),(26,10,36,'Olá! Atendo sim. Do que você precisa?',1,'2026-10-12 02:09:21'),(27,10,45,'Preciso de um orçamento para esta semana. Qual seria o valor?',1,'2026-10-12 02:16:21'),(28,10,36,'Consigo passar aí amanhã para avaliar e já te passo o valor certinho.',1,'2026-10-12 02:23:21'),(29,10,45,'Perfeito, combinado!',0,'2026-10-12 02:30:21'),(30,11,43,'Boa tarde! Você tem horário disponível no sábado?',1,'2026-10-05 02:16:21'),(31,11,30,'Boa tarde! Tenho às 9h ou às 14h.',1,'2026-10-05 02:23:21'),(32,11,43,'Pode ser às 9h. Obrigado!',0,'2026-10-05 02:30:21'),(33,12,64,'Oi, tudo bem? Quanto você cobra pelo serviço?',1,'2026-10-12 02:23:21'),(34,12,4,'Tudo ótimo! Depende do tamanho, mas costuma ficar dentro da faixa do meu perfil. Pode me mandar mais detalhes?',0,'2026-10-12 02:30:21'),(35,13,44,'Olá! Vi seu perfil aqui na Nexus. Você atende na minha região?',1,'2026-10-04 02:02:21'),(36,13,9,'Olá! Atendo sim. Do que você precisa?',1,'2026-10-04 02:09:21'),(37,13,44,'Preciso de um orçamento para esta semana. Qual seria o valor?',1,'2026-10-04 02:16:21'),(38,13,9,'Consigo passar aí amanhã para avaliar e já te passo o valor certinho.',1,'2026-10-04 02:23:21'),(39,13,44,'Perfeito, combinado!',0,'2026-10-04 02:30:21'),(40,14,54,'Olá! Vi seu perfil aqui na Nexus. Você atende na minha região?',1,'2026-10-04 02:02:21'),(41,14,9,'Olá! Atendo sim. Do que você precisa?',1,'2026-10-04 02:09:21'),(42,14,54,'Preciso de um orçamento para esta semana. Qual seria o valor?',1,'2026-10-04 02:16:21'),(43,14,9,'Consigo passar aí amanhã para avaliar e já te passo o valor certinho.',1,'2026-10-04 02:23:21'),(44,14,54,'Perfeito, combinado!',0,'2026-10-04 02:30:21'),(45,15,63,'Olá! Vi seu perfil aqui na Nexus. Você atende na minha região?',1,'2026-10-14 02:02:21'),(46,15,10,'Olá! Atendo sim. Do que você precisa?',1,'2026-10-14 02:09:21'),(47,15,63,'Preciso de um orçamento para esta semana. Qual seria o valor?',1,'2026-10-14 02:16:21'),(48,15,10,'Consigo passar aí amanhã para avaliar e já te passo o valor certinho.',1,'2026-10-14 02:23:21'),(49,15,63,'Perfeito, combinado!',0,'2026-10-14 02:30:21'),(50,16,61,'Oi, tudo bem? Quanto você cobra pelo serviço?',1,'2026-10-08 02:23:21'),(51,16,32,'Tudo ótimo! Depende do tamanho, mas costuma ficar dentro da faixa do meu perfil. Pode me mandar mais detalhes?',0,'2026-10-08 02:30:21'),(52,17,58,'Oi, tudo bem? Quanto você cobra pelo serviço?',1,'2026-10-03 02:23:21'),(53,17,6,'Tudo ótimo! Depende do tamanho, mas costuma ficar dentro da faixa do meu perfil. Pode me mandar mais detalhes?',0,'2026-10-03 02:30:21');
/*!40000 ALTER TABLE `mensagens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prestador_categorias`
--

DROP TABLE IF EXISTS `prestador_categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prestador_categorias` (
  `prestador_id` int(10) unsigned NOT NULL,
  `categoria_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`prestador_id`,`categoria_id`),
  KEY `fk_pc_categoria` (`categoria_id`),
  CONSTRAINT `fk_pc_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pc_prestador` FOREIGN KEY (`prestador_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prestador_categorias`
--

LOCK TABLES `prestador_categorias` WRITE;
/*!40000 ALTER TABLE `prestador_categorias` DISABLE KEYS */;
INSERT INTO `prestador_categorias` VALUES (2,1),(3,4),(4,1),(4,2),(5,6),(6,7),(7,8),(8,6),(9,5),(10,1),(11,1),(11,2),(12,5),(13,7),(14,2),(15,2),(16,4),(17,2),(18,1),(19,8),(20,5),(21,3),(22,2),(23,6),(24,4),(25,3),(26,6),(27,8),(28,8),(29,6),(29,7),(30,7),(31,6),(31,7),(32,2),(33,6),(34,4),(35,5),(36,1),(37,1),(38,4),(39,6),(40,7),(41,5),(42,1);
/*!40000 ALTER TABLE `prestador_categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prestador_horarios`
--

DROP TABLE IF EXISTS `prestador_horarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prestador_horarios` (
  `prestador_id` int(10) unsigned NOT NULL,
  `dia_semana` tinyint(3) unsigned NOT NULL,
  `inicio` time NOT NULL,
  `fim` time NOT NULL,
  PRIMARY KEY (`prestador_id`,`dia_semana`),
  CONSTRAINT `fk_horario_prestador` FOREIGN KEY (`prestador_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ck_horario_dia` CHECK (`dia_semana` between 0 and 6),
  CONSTRAINT `ck_horario_periodo` CHECK (`fim` > `inicio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prestador_horarios`
--

LOCK TABLES `prestador_horarios` WRITE;
/*!40000 ALTER TABLE `prestador_horarios` DISABLE KEYS */;
INSERT INTO `prestador_horarios` VALUES (2,1,'08:00:00','18:00:00'),(2,2,'08:00:00','18:00:00'),(2,3,'08:00:00','18:00:00'),(2,4,'08:00:00','18:00:00'),(2,5,'08:00:00','18:00:00'),(2,6,'08:00:00','12:00:00'),(3,0,'07:00:00','22:00:00'),(3,1,'07:00:00','22:00:00'),(3,2,'07:00:00','22:00:00'),(3,3,'07:00:00','22:00:00'),(3,4,'07:00:00','22:00:00'),(3,5,'07:00:00','22:00:00'),(3,6,'07:00:00','22:00:00'),(6,0,'10:00:00','18:00:00'),(6,5,'18:00:00','23:00:00'),(6,6,'10:00:00','23:00:00'),(7,1,'07:00:00','12:00:00'),(7,2,'07:00:00','12:00:00'),(7,3,'07:00:00','12:00:00'),(7,4,'07:00:00','12:00:00'),(7,5,'07:00:00','12:00:00'),(7,6,'07:00:00','12:00:00'),(9,1,'13:00:00','21:00:00'),(9,2,'13:00:00','21:00:00'),(9,3,'13:00:00','21:00:00'),(9,4,'13:00:00','21:00:00'),(9,5,'13:00:00','21:00:00'),(10,1,'08:00:00','18:00:00'),(10,2,'08:00:00','18:00:00'),(10,3,'08:00:00','18:00:00'),(10,4,'08:00:00','18:00:00'),(10,5,'08:00:00','18:00:00'),(11,1,'08:00:00','18:00:00'),(11,2,'08:00:00','18:00:00'),(11,3,'08:00:00','18:00:00'),(11,4,'08:00:00','18:00:00'),(11,5,'08:00:00','18:00:00'),(11,6,'08:00:00','12:00:00'),(12,0,'07:00:00','22:00:00'),(12,1,'07:00:00','22:00:00'),(12,2,'07:00:00','22:00:00'),(12,3,'07:00:00','22:00:00'),(12,4,'07:00:00','22:00:00'),(12,5,'07:00:00','22:00:00'),(12,6,'07:00:00','22:00:00'),(13,0,'10:00:00','18:00:00'),(13,5,'18:00:00','23:00:00'),(13,6,'10:00:00','23:00:00'),(14,1,'08:00:00','18:00:00'),(14,2,'08:00:00','18:00:00'),(14,3,'08:00:00','18:00:00'),(14,4,'08:00:00','18:00:00'),(14,5,'08:00:00','18:00:00'),(15,1,'08:00:00','18:00:00'),(15,2,'08:00:00','18:00:00'),(15,3,'08:00:00','18:00:00'),(15,4,'08:00:00','18:00:00'),(15,5,'08:00:00','18:00:00'),(16,1,'08:00:00','18:00:00'),(16,2,'08:00:00','18:00:00'),(16,3,'08:00:00','18:00:00'),(16,4,'08:00:00','18:00:00'),(16,5,'08:00:00','18:00:00'),(17,1,'08:00:00','18:00:00'),(17,2,'08:00:00','18:00:00'),(17,3,'08:00:00','18:00:00'),(17,4,'08:00:00','18:00:00'),(17,5,'08:00:00','18:00:00'),(19,0,'10:00:00','18:00:00'),(19,5,'18:00:00','23:00:00'),(19,6,'10:00:00','23:00:00'),(20,0,'07:00:00','22:00:00'),(20,1,'07:00:00','22:00:00'),(20,2,'07:00:00','22:00:00'),(20,3,'07:00:00','22:00:00'),(20,4,'07:00:00','22:00:00'),(20,5,'07:00:00','22:00:00'),(20,6,'07:00:00','22:00:00'),(21,1,'07:00:00','12:00:00'),(21,2,'07:00:00','12:00:00'),(21,3,'07:00:00','12:00:00'),(21,4,'07:00:00','12:00:00'),(21,5,'07:00:00','12:00:00'),(21,6,'07:00:00','12:00:00'),(22,1,'07:00:00','12:00:00'),(22,2,'07:00:00','12:00:00'),(22,3,'07:00:00','12:00:00'),(22,4,'07:00:00','12:00:00'),(22,5,'07:00:00','12:00:00'),(22,6,'07:00:00','12:00:00'),(23,1,'07:00:00','12:00:00'),(23,2,'07:00:00','12:00:00'),(23,3,'07:00:00','12:00:00'),(23,4,'07:00:00','12:00:00'),(23,5,'07:00:00','12:00:00'),(23,6,'07:00:00','12:00:00'),(24,1,'08:00:00','18:00:00'),(24,2,'08:00:00','18:00:00'),(24,3,'08:00:00','18:00:00'),(24,4,'08:00:00','18:00:00'),(24,5,'08:00:00','18:00:00'),(26,1,'13:00:00','21:00:00'),(26,2,'13:00:00','21:00:00'),(26,3,'13:00:00','21:00:00'),(26,4,'13:00:00','21:00:00'),(26,5,'13:00:00','21:00:00'),(27,1,'13:00:00','21:00:00'),(27,2,'13:00:00','21:00:00'),(27,3,'13:00:00','21:00:00'),(27,4,'13:00:00','21:00:00'),(27,5,'13:00:00','21:00:00'),(28,0,'10:00:00','18:00:00'),(28,5,'18:00:00','23:00:00'),(28,6,'10:00:00','23:00:00'),(29,0,'10:00:00','18:00:00'),(29,5,'18:00:00','23:00:00'),(29,6,'10:00:00','23:00:00'),(32,1,'08:00:00','18:00:00'),(32,2,'08:00:00','18:00:00'),(32,3,'08:00:00','18:00:00'),(32,4,'08:00:00','18:00:00'),(32,5,'08:00:00','18:00:00'),(33,1,'07:00:00','12:00:00'),(33,2,'07:00:00','12:00:00'),(33,3,'07:00:00','12:00:00'),(33,4,'07:00:00','12:00:00'),(33,5,'07:00:00','12:00:00'),(33,6,'07:00:00','12:00:00'),(34,0,'07:00:00','22:00:00'),(34,1,'07:00:00','22:00:00'),(34,2,'07:00:00','22:00:00'),(34,3,'07:00:00','22:00:00'),(34,4,'07:00:00','22:00:00'),(34,5,'07:00:00','22:00:00'),(34,6,'07:00:00','22:00:00'),(35,1,'08:00:00','18:00:00'),(35,2,'08:00:00','18:00:00'),(35,3,'08:00:00','18:00:00'),(35,4,'08:00:00','18:00:00'),(35,5,'08:00:00','18:00:00'),(36,1,'07:00:00','12:00:00'),(36,2,'07:00:00','12:00:00'),(36,3,'07:00:00','12:00:00'),(36,4,'07:00:00','12:00:00'),(36,5,'07:00:00','12:00:00'),(36,6,'07:00:00','12:00:00'),(37,1,'08:00:00','18:00:00'),(37,2,'08:00:00','18:00:00'),(37,3,'08:00:00','18:00:00'),(37,4,'08:00:00','18:00:00'),(37,5,'08:00:00','18:00:00'),(39,1,'08:00:00','18:00:00'),(39,2,'08:00:00','18:00:00'),(39,3,'08:00:00','18:00:00'),(39,4,'08:00:00','18:00:00'),(39,5,'08:00:00','18:00:00'),(39,6,'08:00:00','12:00:00'),(40,0,'10:00:00','18:00:00'),(40,5,'18:00:00','23:00:00'),(40,6,'10:00:00','23:00:00'),(42,1,'07:00:00','12:00:00'),(42,2,'07:00:00','12:00:00'),(42,3,'07:00:00','12:00:00'),(42,4,'07:00:00','12:00:00'),(42,5,'07:00:00','12:00:00'),(42,6,'07:00:00','12:00:00');
/*!40000 ALTER TABLE `prestador_horarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prestador_perfis`
--

DROP TABLE IF EXISTS `prestador_perfis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prestador_perfis` (
  `usuario_id` int(10) unsigned NOT NULL,
  `profissao` varchar(80) NOT NULL,
  `descricao` text DEFAULT NULL,
  `preco_min` decimal(10,2) DEFAULT NULL,
  `preco_max` decimal(10,2) DEFAULT NULL,
  `verificado_em` datetime DEFAULT NULL COMMENT 'Selo de verificado, concedido por um admin',
  PRIMARY KEY (`usuario_id`),
  CONSTRAINT `fk_perfil_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ck_perfil_precos` CHECK (`preco_min` is null or `preco_max` is null or `preco_min` <= `preco_max`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prestador_perfis`
--

LOCK TABLES `prestador_perfis` WRITE;
/*!40000 ALTER TABLE `prestador_perfis` DISABLE KEYS */;
INSERT INTO `prestador_perfis` VALUES (2,'Eletricista','Conta de teste do tipo prestador. Use para ver o painel e responder conversas.',80.00,250.00,NULL),(3,'Técnico de celular','Troca de tela, bateria e conector, além de recuperação de aparelhos molhados.',58.00,460.00,NULL),(4,'Marido de aluguel','Pequenos reparos em geral: montagem de móveis, instalação de prateleiras, cortinas, suportes de TV e ajustes em portas.',NULL,NULL,NULL),(5,'Personal trainer','Treinos personalizados em domicílio, academia ou ao ar livre.',85.00,159.00,NULL),(6,'DJ','Som e iluminação para festas, casamentos e formaturas.',470.00,1880.00,NULL),(7,'Lavador de carros','Lavagem completa, higienização interna e polimento, com atendimento no local.',NULL,NULL,NULL),(8,'Manicure','Manicure, pedicure, alongamento em gel e esmaltação em gel.',NULL,NULL,NULL),(9,'Professor de violão','Aulas de violão para iniciantes e intermediários, do básico às cifras.',57.00,86.00,NULL),(10,'Eletricista','Instalações e reparos elétricos residenciais e comerciais: tomadas, chuveiros, disjuntores, iluminação e quadros de energia.',90.00,336.00,'2026-10-05 13:01:39'),(11,'Marido de aluguel',NULL,55.00,182.00,'2026-10-05 13:01:39'),(12,'Professora de inglês','Inglês para todas as idades, presencial ou on-line, com foco em conversação.',61.00,101.00,NULL),(13,'DJ','Som e iluminação para festas, casamentos e formaturas.',430.00,1720.00,NULL),(14,'Pedreiro','Construção, reformas, contrapiso, reboco e assentamento de pisos. Orçamento sem compromisso no local.',NULL,NULL,NULL),(15,'Gesseiro',NULL,452.00,3390.00,NULL),(16,'Técnico de celular',NULL,51.00,404.00,NULL),(17,'Gesseiro','Forros, sancas, divisórias de drywall e molduras em gesso.',348.00,2610.00,NULL),(18,'Encanador','Conserto de vazamentos, desentupimentos, troca de registros e instalação de caixas d\'água e aquecedores.',91.00,354.00,NULL),(19,'Mecânico','Mecânica geral, freios, suspensão e injeção eletrônica. Valor conforme diagnóstico.',NULL,NULL,NULL),(20,'Professor de matemática','Aulas particulares e reforço do ensino fundamental ao vestibular.',59.00,105.00,NULL),(21,'Limpeza pós-obra',NULL,300.00,900.00,NULL),(22,'Pintor','Pintura interna e externa, texturas, grafiato, massa corrida e acabamento fino.',255.00,2125.00,NULL),(23,'Personal trainer',NULL,81.00,152.00,NULL),(24,'Técnico em informática','Formatação, remoção de vírus, upgrade de peças e configuração de redes e impressoras.',68.00,243.00,NULL),(25,'Diarista','Limpeza residencial completa, organização e passadoria.',144.00,211.00,NULL),(26,'Cabeleireira','Cortes, escova, coloração e mechas. Atendimento em domicílio.',54.00,375.00,NULL),(27,'Lavador de carros','Lavagem completa, higienização interna e polimento, com atendimento no local.',36.00,225.00,NULL),(28,'Mecânico','Mecânica geral, freios, suspensão e injeção eletrônica. Valor conforme diagnóstico.',NULL,NULL,'2026-10-05 13:01:39'),(29,'Maquiadora','Maquiagem social, para noivas e formaturas, com teste prévio.',119.00,396.00,NULL),(30,'Confeiteira','Bolos decorados, doces finos e mesas de doces para festas.',NULL,NULL,NULL),(31,'Maquiadora','Maquiagem social, para noivas e formaturas, com teste prévio.',NULL,NULL,NULL),(32,'Pintor',NULL,288.00,2400.00,NULL),(33,'Manicure','Manicure, pedicure, alongamento em gel e esmaltação em gel.',35.00,104.00,'2026-10-05 13:01:39'),(34,'Desenvolvedor de sites','Sites institucionais, lojas virtuais e landing pages responsivas, com hospedagem e domínio.',840.00,5250.00,NULL),(35,'Professora de inglês','Inglês para todas as idades, presencial ou on-line, com foco em conversação.',72.00,120.00,NULL),(36,'Eletricista','Instalações e reparos elétricos residenciais e comerciais: tomadas, chuveiros, disjuntores, iluminação e quadros de energia.',76.00,285.00,'2026-10-05 13:01:39'),(37,'Montador de móveis',NULL,65.00,233.00,NULL),(38,'Desenvolvedor de sites','Sites institucionais, lojas virtuais e landing pages responsivas, com hospedagem e domínio.',960.00,6000.00,'2026-10-05 13:01:39'),(39,'Cabeleireira','Cortes, escova, coloração e mechas. Atendimento em domicílio.',NULL,NULL,'2026-10-05 13:01:39'),(40,'Fotógrafo','Casamentos, aniversários, ensaios e eventos corporativos, com fotos tratadas em galeria on-line.',388.00,2425.00,NULL),(41,'Professor de violão','Aulas de violão para iniciantes e intermediários, do básico às cifras.',64.00,96.00,NULL),(42,'Montador de móveis','Montagem e desmontagem de móveis planejados e de loja, com cuidado e ferramentas próprias.',71.00,253.00,'2026-10-05 13:01:39');
/*!40000 ALTER TABLE `prestador_perfis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `redefinicoes_senha`
--

DROP TABLE IF EXISTS `redefinicoes_senha`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `redefinicoes_senha` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario_id` int(10) unsigned NOT NULL,
  `codigo_hash` varchar(255) NOT NULL,
  `tentativas` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `usado` tinyint(1) NOT NULL DEFAULT 0,
  `expira_em` datetime NOT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_redefinicoes_usuario` (`usuario_id`),
  CONSTRAINT `fk_redefinicao_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `redefinicoes_senha`
--

LOCK TABLES `redefinicoes_senha` WRITE;
/*!40000 ALTER TABLE `redefinicoes_senha` DISABLE KEYS */;
/*!40000 ALTER TABLE `redefinicoes_senha` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipo` enum('cliente','prestador','admin') NOT NULL,
  `nome` varchar(120) NOT NULL,
  `email` varchar(150) NOT NULL,
  `senha` varchar(255) DEFAULT NULL COMMENT 'NULL para contas criadas só com Google',
  `cpf` char(11) DEFAULT NULL,
  `data_nasc` date DEFAULT NULL,
  `genero` varchar(30) DEFAULT NULL,
  `telefone` varchar(11) DEFAULT NULL,
  `estado` char(2) DEFAULT NULL,
  `cidade` varchar(100) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `foto` varchar(500) DEFAULT NULL,
  `google_id` varchar(64) DEFAULT NULL,
  `suspenso_em` datetime DEFAULT NULL COMMENT 'Preenchido quando um admin suspende a conta',
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  `atualizado_em` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_usuarios_email` (`email`),
  UNIQUE KEY `uq_usuarios_cpf` (`cpf`),
  UNIQUE KEY `uq_usuarios_google` (`google_id`),
  KEY `idx_usuarios_tipo` (`tipo`),
  KEY `idx_usuarios_local` (`latitude`,`longitude`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'cliente','Cliente Teste','cliente@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10000791989','1994-01-20','Feminino','18991418707','SP','Presidente Prudente',-22.11440000,-51.38510000,NULL,NULL,NULL,'2026-09-15 02:37:21','2026-10-15 02:37:21'),(2,'prestador','Prestador Teste','prestador@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10001583816','1980-04-10','Masculino','18975091823','SP','Presidente Prudente',-22.13120000,-51.39380000,NULL,NULL,NULL,'2026-09-15 02:37:21','2026-10-15 02:37:21'),(3,'prestador','João Costa Pereira','joao.pereira3@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10002375753','1985-02-17','Masculino','18934777186','SP','Assis',-22.64070000,-50.43200000,NULL,NULL,NULL,'2026-01-19 02:37:21','2026-10-15 02:37:21'),(4,'prestador','Diego Rocha Ferreira','diego.ferreira4@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10003167690','2000-01-24','Masculino','18930618355','SP','Martinópolis',-22.14880000,-51.14700000,NULL,NULL,NULL,'2026-03-13 02:37:21','2026-10-15 02:37:21'),(5,'prestador','Mariana Ferreira Rodrigues','mariana.rodrigues5@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10003959520','1977-02-01','Feminino','18964262357','SP','Presidente Prudente',-22.10630000,-51.36700000,NULL,NULL,NULL,'2025-09-25 02:37:21','2026-10-15 02:37:21'),(6,'prestador','William Mendes Cardoso','william.cardoso6@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10004751400','1987-01-16','Masculino','18985057994','SP','Presidente Epitácio',-21.75050000,-52.09860000,NULL,NULL,NULL,'2025-12-04 02:37:21','2026-10-15 02:37:21'),(7,'prestador','Daniela Araújo Barbosa','daniela.barbosa7@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10005543339','1972-03-26','Feminino','18914187608','SP','Presidente Prudente',-22.14780000,-51.39570000,NULL,NULL,NULL,'2025-11-18 02:37:21','2026-10-15 02:37:21'),(8,'prestador','Daniela Barbosa Cardoso','daniela.cardoso8@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10006335276','1966-03-05','Feminino','18928329893','SP','Marília',-22.20580000,-49.93460000,NULL,NULL,NULL,'2026-01-02 02:37:21','2026-10-15 02:37:21'),(9,'prestador','Juliana Gomes Teixeira','juliana.teixeira9@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10007127103','1988-08-26','Feminino','18922329745','SP','Presidente Prudente',-22.12570000,-51.40400000,NULL,NULL,NULL,'2026-02-10 02:37:21','2026-10-15 02:37:21'),(10,'prestador','Samuel Martins Martins','samuel.martins10@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10007919042','1966-08-12','Masculino','18934230643','SP','Álvares Machado',-22.07550000,-51.49410000,NULL,NULL,NULL,'2026-05-06 02:37:21','2026-10-15 02:37:21'),(11,'prestador','Marcos Pereira Rodrigues','marcos.rodrigues11@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10008710961','1988-04-13','Masculino','18913346888','SP','Regente Feijó',-22.24470000,-51.32770000,NULL,NULL,NULL,'2026-04-27 02:37:21','2026-10-15 02:37:21'),(12,'prestador','Patrícia Santos Araújo','patricia.araujo12@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10009502807','1980-09-20','Feminino','18937642512','SP','Presidente Prudente',-22.10880000,-51.38250000,NULL,NULL,NULL,'2026-02-11 02:37:21','2026-10-15 02:37:21'),(13,'prestador','Fernanda Ribeiro Moreira','fernanda.moreira13@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10010294708','2000-04-07','Feminino','11948777097','SP','São Paulo',-23.53520000,-46.65150000,NULL,NULL,NULL,'2026-08-15 02:37:21','2026-10-15 02:37:21'),(14,'prestador','Marcos Martins Pereira','marcos.pereira14@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10011086637','1980-11-28','Masculino','11979623331','SP','São Paulo',-23.52640000,-46.65500000,NULL,NULL,NULL,'2025-10-07 02:37:21','2026-10-15 02:37:21'),(15,'prestador','Eduardo Silva Martins','eduardo.martins15@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10011878576','1978-11-23','Masculino','18936956156','SP','Presidente Venceslau',-21.89680000,-51.83700000,NULL,NULL,NULL,'2026-05-25 02:37:21','2026-10-15 02:37:21'),(16,'prestador','Paulo Gomes Teixeira','paulo.teixeira16@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10012670448','1995-12-28','Masculino','18963538350','SP','Santo Anastácio',-21.96500000,-51.64870000,NULL,NULL,NULL,'2025-11-07 02:37:21','2026-10-15 02:37:21'),(17,'prestador','Larissa Cardoso Ribeiro','larissa.ribeiro17@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10013462385','1971-07-09','Feminino','18977592868','SP','Presidente Prudente',-22.12810000,-51.40250000,NULL,NULL,NULL,'2026-04-19 02:37:21','2026-10-15 02:37:21'),(18,'prestador','Carlos Carvalho Mendes','carlos.mendes18@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10014254212','1971-03-01','Masculino','11912237316','SP','São Paulo',-23.56280000,-46.65110000,NULL,NULL,NULL,'2026-04-26 02:37:21','2026-10-15 02:37:21'),(19,'prestador','Carlos Rodrigues Araújo','carlos.araujo19@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10015046150','1976-05-27','Masculino','18955472553','SP','Presidente Venceslau',-21.89100000,-51.82330000,NULL,NULL,NULL,'2026-03-01 02:37:21','2026-10-15 02:37:21'),(20,'prestador','Rafael Almeida Oliveira','rafael.oliveira20@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10015838099','1981-04-28','Masculino','18971986163','SP','Santo Anastácio',-21.96520000,-51.66760000,NULL,NULL,NULL,'2026-09-22 02:37:21','2026-10-15 02:37:21'),(21,'prestador','Lucas Rodrigues Sandoval','lucas.sandoval21@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10016629973','1976-03-19','Masculino','18964500566','SP','Presidente Prudente',-22.11660000,-51.38650000,NULL,NULL,NULL,'2026-09-09 02:37:21','2026-10-15 02:37:21'),(22,'prestador','Thiago Moreira Nascimento','thiago.nascimento22@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10017421845','1983-09-10','Masculino','18986498180','SP','Presidente Prudente',-22.10300000,-51.39390000,NULL,NULL,NULL,'2025-10-07 02:37:21','2026-10-15 02:37:21'),(23,'prestador','Samuel Oliveira Lima','samuel.lima23@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10018213782','1998-04-18','Masculino','18990228172','SP','Regente Feijó',-22.22600000,-51.31630000,NULL,NULL,NULL,'2025-11-28 02:37:21','2026-10-15 02:37:21'),(24,'prestador','Gustavo Araújo Oliveira','gustavo.oliveira24@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10019005610','1992-07-11','Masculino','18996045265','SP','Assis',-22.68390000,-50.40200000,NULL,NULL,NULL,'2026-01-13 02:37:21','2026-10-15 02:37:21'),(25,'prestador','Yasmin Moreira Moreira','yasmin.moreira25@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10019797532','1994-08-27','Feminino','18915213262','SP','Álvares Machado',-22.08720000,-51.45380000,NULL,NULL,NULL,'2025-11-17 02:37:21','2026-10-15 02:37:21'),(26,'prestador','Vanessa Araújo Barbosa','vanessa.barbosa26@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10020589450','2003-06-12','Feminino','18914722512','SP','Presidente Prudente',-22.13470000,-51.39790000,NULL,NULL,NULL,'2026-09-30 02:37:21','2026-10-15 02:37:21'),(27,'prestador','Gustavo Oliveira Barbosa','gustavo.barbosa27@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10021381321','1992-01-13','Masculino','18995918659','SP','Presidente Prudente',-22.12350000,-51.38880000,NULL,NULL,NULL,'2026-06-16 02:37:21','2026-10-15 02:37:21'),(28,'prestador','Diego Pereira Pereira','diego.pereira28@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10022173269','1975-02-16','Masculino','18952303565','SP','Presidente Prudente',-22.10350000,-51.38340000,NULL,NULL,NULL,'2025-09-12 02:37:21','2026-10-15 02:37:21'),(29,'prestador','Ana Santos Martins','ana.martins29@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10022965106','1984-11-21','Feminino','18912424407','SP','Presidente Venceslau',-21.87370000,-51.83420000,NULL,NULL,NULL,'2025-12-18 02:37:21','2026-10-15 02:37:21'),(30,'prestador','Eduarda Ferreira Ribeiro','eduarda.ribeiro30@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10023757035','1967-07-05','Feminino','18952397619','SP','Presidente Prudente',-22.10890000,-51.40480000,NULL,NULL,NULL,'2026-07-01 02:37:21','2026-10-15 02:37:21'),(31,'prestador','Isabela Souza Araújo','isabela.araujo31@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10024548910','1990-03-27','Feminino','18936288411','SP','Presidente Prudente',-22.14600000,-51.38870000,NULL,NULL,NULL,'2025-12-19 02:37:21','2026-10-15 02:37:21'),(32,'prestador','André Costa Silva','andre.silva32@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10025340891','1987-08-27','Masculino','18933515826','SP','Assis',-22.67030000,-50.42550000,NULL,NULL,NULL,'2026-04-29 02:37:21','2026-10-15 02:37:21'),(33,'prestador','Larissa Almeida Nascimento','larissa.nascimento33@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10026132729','1977-10-03','Feminino','18973993199','SP','Pirapozinho',-22.29020000,-51.52500000,NULL,NULL,NULL,'2025-11-19 02:37:21','2026-10-15 02:37:21'),(34,'prestador','Juliana Castro Castro','juliana.castro34@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10026924668','2005-11-26','Feminino','18942626173','SP','Pirapozinho',-22.27170000,-51.48700000,NULL,NULL,NULL,'2026-06-06 02:37:21','2026-10-15 02:37:21'),(35,'prestador','Luana Martins Rodrigues','luana.rodrigues35@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10027716503','1998-08-11','Feminino','18964010953','SP','Presidente Epitácio',-21.78420000,-52.11640000,NULL,NULL,NULL,'2025-10-26 02:37:21','2026-10-15 02:37:21'),(36,'prestador','Otávio Oliveira Lima','otavio.lima36@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10028508432','1965-04-07','Masculino','18975948628','SP','Martinópolis',-22.12960000,-51.16250000,NULL,NULL,NULL,'2025-10-21 02:37:21','2026-10-15 02:37:21'),(37,'prestador','Vanessa Moreira Gomes','vanessa.gomes37@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10029300304','2002-01-09','Feminino','18911818733','SP','Presidente Venceslau',-21.89780000,-51.83620000,NULL,NULL,NULL,'2026-05-06 02:37:21','2026-10-15 02:37:21'),(38,'prestador','Camila Castro Santos','camila.santos38@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10030092205','1977-04-20','Feminino','18982489820','SP','Presidente Prudente',-22.14110000,-51.40840000,NULL,NULL,NULL,'2026-06-22 02:37:21','2026-10-15 02:37:21'),(39,'prestador','Patrícia Lima Souza','patricia.souza39@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10030884144','1989-04-01','Feminino','18921141877','SP','Presidente Prudente',-22.13930000,-51.40100000,NULL,NULL,NULL,'2026-01-07 02:37:21','2026-10-15 02:37:21'),(40,'prestador','Henrique Barbosa Cardoso','henrique.cardoso40@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10031676081','1968-03-02','Masculino','18960545003','SP','Presidente Prudente',-22.10450000,-51.37230000,NULL,NULL,NULL,'2026-05-05 02:37:21','2026-10-15 02:37:21'),(41,'prestador','Gustavo Mendes Santos','gustavo.santos41@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10032467966','1998-08-03','Masculino','11963934628','SP','São Paulo',-23.54130000,-46.65750000,NULL,NULL,NULL,'2025-10-04 02:37:21','2026-10-15 02:37:21'),(42,'prestador','Lucas Nascimento Carvalho','lucas.carvalho42@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10033259801','1979-10-18','Masculino','18988306609','SP','Presidente Prudente',-22.14690000,-51.39750000,NULL,NULL,'2026-10-07 23:37:21','2026-06-26 02:37:21','2026-10-15 02:37:21'),(43,'cliente','Tatiane Cardoso Sandoval','tatiane.sandoval43@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10034051775','2003-08-08','Feminino','11974146571','SP','São Paulo',-23.56000000,-46.65250000,NULL,NULL,NULL,'2026-03-21 02:37:21','2026-10-15 02:37:21'),(44,'cliente','Natália Ribeiro Rocha','natalia.rocha44@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10034843604','1966-06-27','Feminino','18971490404','SP','Presidente Prudente',-22.12530000,-51.39350000,NULL,NULL,NULL,'2025-09-27 02:37:21','2026-10-15 02:37:21'),(45,'cliente','Patrícia Cardoso Teixeira','patricia.teixeira45@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10035635541','1999-02-19','Feminino','18950471229','SP','Presidente Prudente',-22.12140000,-51.37990000,NULL,NULL,NULL,'2026-04-18 02:37:21','2026-10-15 02:37:21'),(46,'cliente','Nicolas Nascimento Mendes','nicolas.mendes46@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10036427489','1975-05-23','Masculino','18999332338','SP','Presidente Prudente',-22.11560000,-51.39220000,NULL,NULL,NULL,'2025-12-18 02:37:21','2026-10-15 02:37:21'),(47,'cliente','Paulo Castro Nascimento','paulo.nascimento47@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10037219316','2000-08-15','Masculino','18915253568','SP','Álvares Machado',-22.09690000,-51.46850000,NULL,NULL,NULL,'2026-04-04 02:37:21','2026-10-15 02:37:21'),(48,'cliente','Luana Souza Teixeira','luana.teixeira48@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10038011298','1994-09-10','Feminino','18911007230','SP','Presidente Prudente',-22.12330000,-51.36940000,NULL,NULL,NULL,'2026-04-18 02:37:21','2026-10-15 02:37:21'),(49,'cliente','Sofia Gomes Araújo','sofia.araujo49@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10038803127','1966-02-27','Feminino','18992918905','SP','Presidente Epitácio',-21.77190000,-52.09630000,NULL,NULL,NULL,'2026-03-20 02:37:21','2026-10-15 02:37:21'),(50,'cliente','Ana Souza Rocha','ana.rocha50@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10039595048','1966-02-05','Feminino','11985388297','SP','São Paulo',-23.56570000,-46.63820000,NULL,NULL,NULL,'2026-05-15 02:37:21','2026-10-15 02:37:21'),(51,'cliente','Beatriz Nascimento Rocha','beatriz.rocha51@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10040386902','1983-11-01','Feminino','18976730235','SP','Presidente Prudente',-22.13380000,-51.41290000,NULL,NULL,NULL,'2025-11-22 02:37:21','2026-10-15 02:37:21'),(52,'cliente','Lucas Cardoso Almeida','lucas.almeida52@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10041178840','2002-01-10','Masculino','18978324695','SP','Marília',-22.19550000,-49.93420000,NULL,NULL,NULL,'2026-03-15 02:37:21','2026-10-15 02:37:21'),(53,'cliente','Rafaela Ferreira Castro','rafaela.castro53@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10041970713','1995-08-18','Feminino','18947678669','SP','Regente Feijó',-22.20100000,-51.29550000,NULL,NULL,NULL,'2026-07-15 02:37:21','2026-10-15 02:37:21'),(54,'cliente','Tatiane Sandoval Barbosa','tatiane.barbosa54@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10042762650','1985-06-16','Feminino','18957783854','SP','Martinópolis',-22.14380000,-51.18790000,NULL,NULL,NULL,'2025-09-30 02:37:21','2026-10-15 02:37:21'),(55,'cliente','Juliana Teixeira Barbosa','juliana.barbosa55@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10043554598','1999-02-13','Feminino','18913367546','SP','Presidente Prudente',-22.14680000,-51.40870000,NULL,NULL,NULL,'2025-10-17 02:37:21','2026-10-15 02:37:21'),(56,'cliente','Felipe Lima Costa','felipe.costa56@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10044346425','2000-12-24','Masculino','18948891095','SP','Presidente Prudente',-22.14910000,-51.41010000,NULL,NULL,NULL,'2026-04-05 02:37:21','2026-10-15 02:37:21'),(57,'cliente','Luana Gomes Martins','luana.martins57@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10045138362','1979-02-04','Feminino','18959625300','SP','Marília',-22.22750000,-49.95090000,NULL,NULL,NULL,'2026-06-02 02:37:21','2026-10-15 02:37:21'),(58,'cliente','Daniela Ferreira Ribeiro','daniela.ribeiro58@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10045930236','1979-03-10','Feminino','18997409082','SP','Presidente Epitácio',-21.74560000,-52.12880000,NULL,NULL,NULL,'2025-12-15 02:37:21','2026-10-15 02:37:21'),(59,'cliente','Beatriz Ferreira Mendes','beatriz.mendes59@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10046722173','1969-12-02','Feminino','18932181321','SP','Martinópolis',-22.13490000,-51.15830000,NULL,NULL,NULL,'2025-09-19 02:37:21','2026-10-15 02:37:21'),(60,'cliente','Vanessa Oliveira Gomes','vanessa.gomes60@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10047514000','1973-12-22','Feminino','18928903515','SP','Presidente Venceslau',-21.89770000,-51.84600000,NULL,NULL,NULL,'2025-12-03 02:37:21','2026-10-15 02:37:21'),(61,'cliente','Gustavo Ribeiro Rocha','gustavo.rocha61@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10048305995','1984-02-21','Masculino','18943298760','SP','Pirapozinho',-22.28070000,-51.50190000,NULL,NULL,NULL,'2026-01-07 02:37:21','2026-10-15 02:37:21'),(62,'cliente','Tatiane Nascimento Castro','tatiane.castro62@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10049097806','1984-05-17','Feminino','18956987984','SP','Presidente Prudente',-22.13720000,-51.38010000,NULL,NULL,NULL,'2026-01-13 02:37:21','2026-10-15 02:37:21'),(63,'cliente','Vinícius Lima Gomes','vinicius.gomes63@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10049889745','1981-03-15','Masculino','18944688902','SP','Presidente Prudente',-22.11840000,-51.38270000,NULL,NULL,NULL,'2026-01-04 02:37:21','2026-10-15 02:37:21'),(64,'cliente','Vinícius Cardoso Ferreira','vinicius.ferreira64@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10050681605','1965-09-07','Masculino','18990085032','SP','Presidente Prudente',-22.10080000,-51.38350000,NULL,NULL,NULL,'2026-09-30 02:37:21','2026-10-15 02:37:21'),(65,'cliente','Ana Silva Oliveira','ana.oliveira65@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10051473534','1977-10-03','Feminino','18965194857','SP','Pirapozinho',-22.26300000,-51.49430000,NULL,NULL,NULL,'2026-03-15 02:37:21','2026-10-15 02:37:21'),(66,'cliente','Igor Silva Costa','igor.costa66@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10052265471','2002-11-12','Masculino','18917797537','SP','Regente Feijó',-22.23250000,-51.28120000,NULL,NULL,NULL,'2026-03-10 02:37:21','2026-10-15 02:37:21'),(67,'cliente','Igor Pereira Pereira','igor.pereira67@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC','10053057309','1981-08-09','Masculino','18987672675','SP','Presidente Prudente',-22.10650000,-51.39410000,NULL,NULL,'2026-10-11 23:37:21','2025-11-17 02:37:21','2026-10-15 02:37:21'),(68,'admin','Administrador Nexus','admin@teste.com','$2y$10$/ie0havB967b6Zp9wmChJe5PL/Doq.8.rYCEIvEMYzleLv4yo.wxC',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-09-10 02:37:21','2026-10-15 02:37:21');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'nexus_network_teste'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-15 13:13:34
