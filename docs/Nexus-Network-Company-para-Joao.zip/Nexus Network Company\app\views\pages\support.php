<?php
$faq = [
    'clientes' => ['Para clientes', 'fa-user', [
        ['Como encontro um profissional?', 'Na página inicial ou em "Buscar profissionais", digite o serviço que precisa (ex.: eletricista) e sua cidade. Você pode filtrar por categoria e distância e ordenar pelos mais próximos, melhor avaliados ou menor preço.'],
        ['Preciso de conta para buscar?', 'Não. A busca e os perfis são abertos. Para ver telefone e e-mail, conversar pelo chat e avaliar, é preciso criar uma conta de cliente (é grátis).'],
        ['Como falo com o profissional?', 'No perfil do prestador, clique em "Enviar mensagem". A conversa fica salva em "Conversas" e você recebe as respostas sem precisar recarregar a página.'],
        ['Como funcionam as avaliações?', 'Cada cliente pode avaliar um profissional uma vez, com nota de 1 a 5 estrelas e um comentário. Se mudar de ideia, exclua sua avaliação e envie outra.'],
        ['Como a distância é calculada?', 'Usamos a cidade do seu cadastro ou a localização do navegador (se você permitir) e calculamos a distância em linha reta até a cidade do profissional.'],
    ]],
    'profissionais' => ['Para profissionais', 'fa-briefcase', [
        ['Como me cadastro como prestador?', 'Clique em "Criar conta", escolha "Sou prestador" e preencha seus dados, profissão, categorias, descrição e faixa de preço. Seu perfil passa a aparecer nas buscas na hora.'],
        ['A plataforma cobra alguma taxa?', 'Não. O cadastro e o uso são gratuitos. O valor do serviço é combinado diretamente entre você e o cliente.'],
        ['Posso deixar o preço em aberto?', 'Sim. Marque "Preço a combinar" no cadastro ou no seu perfil. Você também pode informar só um valor mínimo.'],
        ['Como apareço mais nas buscas?', 'Mantenha o perfil completo: foto, descrição detalhada, categorias certas e cidade correta. Bons atendimentos geram boas avaliações, que melhoram sua posição na ordenação por avaliação.'],
        ['Posso iniciar conversa com um cliente?', 'As conversas são iniciadas pelos clientes. Quando alguém enviar uma mensagem, ela aparecerá em "Conversas" e você poderá responder.'],
    ]],
    'conta' => ['Conta e segurança', 'fa-shield-halved', [
        ['Esqueci minha senha. E agora?', 'Na tela de login, clique em "Esqueci minha senha", informe seu e-mail e digite o código de 6 dígitos que enviaremos. O código vale por 10 minutos.'],
        ['Posso entrar com o Google?', 'Sim. Use "Continuar com Google". Se já tiver conta com o mesmo e-mail, ela será vinculada automaticamente.'],
        ['Como altero meus dados?', 'Em "Meu perfil" você altera nome, telefone, gênero, cidade, foto e senha. E-mail, CPF e data de nascimento não podem ser alterados.'],
        ['Como excluo minha conta?', 'Em "Meu perfil", na seção "Excluir conta", confirme com sua senha. Todos os seus dados, conversas e avaliações são apagados.'],
        ['Meus dados estão seguros?', 'Senhas são guardadas criptografadas, telefone e e-mail só aparecem para usuários logados, e seguimos os princípios da LGPD. Veja os detalhes em "Termos e privacidade".'],
    ]],
];
?>
<section class="page-hero">
    <div class="hero-glow" aria-hidden="true"></div>
    <div class="container">
        <span class="eyebrow">Central de ajuda</span>
        <h1>Como podemos <span class="text-gradient">ajudar?</span></h1>
        <p class="lead">Encontre respostas rápidas ou fale com a nossa equipe.</p>
        <label class="search-bar search-bar-single">
            <span class="search-field">
                <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
                <span class="sr-only">Buscar nas perguntas</span>
                <input type="search" placeholder="Digite sua dúvida, ex.: senha, avaliação, preço…" data-faq-search>
            </span>
        </label>
    </div>
</section>

<section class="section">
    <div class="container faq-layout">
        <div class="faq-tabs" role="tablist" aria-label="Assuntos">
            <button class="faq-tab is-active" type="button" data-faq-tab="todos" role="tab" aria-selected="true"><i class="fa-solid fa-list"></i> Todos</button>
            <?php foreach ($faq as $key => [$label, $icon]): ?>
                <button class="faq-tab" type="button" data-faq-tab="<?= $key ?>" role="tab" aria-selected="false" id="<?= $key ?>"><i class="fa-solid <?= $icon ?>"></i> <?= e($label) ?></button>
            <?php endforeach; ?>
        </div>

        <div class="faq-list">
            <?php foreach ($faq as $key => [$label, $icon, $items]): ?>
                <?php foreach ($items as [$question, $answer]): ?>
                    <details class="faq-item" data-faq-group="<?= $key ?>">
                        <summary><?= e($question) ?> <i class="fa-solid fa-plus" aria-hidden="true"></i></summary>
                        <p><?= e($answer) ?></p>
                    </details>
                <?php endforeach; ?>
            <?php endforeach; ?>
            <div class="empty-state empty-state-sm" data-faq-empty hidden>
                <i class="fa-regular fa-circle-question"></i>
                <p>Nenhuma pergunta encontrada. <a href="<?= url('/contato') ?>">Fale com a gente</a>.</p>
            </div>
        </div>
    </div>
</section>

<section class="section section-alt">
    <div class="container channel-grid">
        <a class="channel-card" href="mailto:<?= e(Config::get('support_email')) ?>">
            <i class="fa-solid fa-envelope"></i>
            <h3>E-mail</h3>
            <p><?= e(Config::get('support_email')) ?></p>
        </a>
        <a class="channel-card" href="<?= url('/contato') ?>">
            <i class="fa-solid fa-message"></i>
            <h3>Formulário de contato</h3>
            <p>Respondemos em até 24 horas úteis</p>
        </a>
        <div class="channel-card">
            <i class="fa-solid fa-clock"></i>
            <h3>Atendimento</h3>
            <p>Segunda a sexta, das 8h às 18h</p>
        </div>
    </div>
</section>
