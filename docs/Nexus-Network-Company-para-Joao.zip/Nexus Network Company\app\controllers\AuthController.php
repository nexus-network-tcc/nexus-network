<?php

final class AuthController
{
    private const MAX_ATTEMPTS = 5;
    private const LOCK_SECONDS = 60;

    public function showLogin(): void
    {
        View::render('auth/login', [
            'title'  => 'Entrar',
            'google' => GoogleOAuth::configured(),
        ]);
    }

    public function login(): void
    {
        $email = mb_strtolower((string) input('email', ''));
        $password = (string) ($_POST['senha'] ?? '');

        $lock = Session::get('login_lock', ['count' => 0, 'until' => 0]);
        if ($lock['until'] > time()) {
            Session::withInput(['email' => $email]);
            Session::flash('error', 'Muitas tentativas. Aguarde ' . ($lock['until'] - time()) . ' segundos e tente novamente.');
            redirect('/entrar');
        }

        $user = $email !== '' ? User::findByEmail($email) : null;

        if ($user && $user['senha'] === null) {
            Session::withInput(['email' => $email]);
            Session::flash('info', 'Esta conta foi criada com o Google. Use "Continuar com Google" ou defina uma senha em "Esqueci minha senha".');
            redirect('/entrar');
        }

        if (!$user || !password_verify($password, $user['senha'])) {
            $lock['count']++;
            if ($lock['count'] >= self::MAX_ATTEMPTS) {
                $lock = ['count' => 0, 'until' => time() + self::LOCK_SECONDS];
            }
            Session::put('login_lock', $lock);
            Session::withInput(['email' => $email]);
            Session::flash('error', 'E-mail ou senha incorretos.');
            redirect('/entrar');
        }

        if ($user['suspenso_em'] !== null) {
            Session::forget('login_lock');
            Session::withInput(['email' => $email]);
            Session::flash('error', 'Conta suspensa. Fale com o suporte: ' . Config::get('support_email'));
            redirect('/entrar');
        }

        if (password_needs_rehash($user['senha'], PASSWORD_DEFAULT)) {
            User::setPassword((int) $user['id'], $password);
        }

        Session::forget('login_lock');
        Auth::login($user);
        Session::flash('success', 'Olá, ' . first_name($user['nome']) . '! Que bom ter você de volta.');
        $this->redirectAfterLogin();
    }

    public function logout(): void
    {
        Auth::logout();
        Session::start();
        Session::flash('success', 'Você saiu da sua conta.');
        redirect('/');
    }

    public static function redirectAfterLogin(): never
    {
        $intended = Session::get('intended');
        Session::forget('intended');
        if (is_string($intended) && str_starts_with($intended, url('/')) && !str_starts_with($intended, '//')) {
            header('Location: ' . $intended);
            exit;
        }
        redirect(match (Auth::user()['tipo']) {
            'admin'     => '/admin',
            'prestador' => '/perfil',
            default     => '/buscar',
        });
    }
}
