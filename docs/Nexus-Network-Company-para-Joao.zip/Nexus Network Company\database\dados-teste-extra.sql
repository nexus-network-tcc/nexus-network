-- Dados fictícios extras do banco de teste: selos de verificado, buscas e denúncias.
-- Incluído por gerar-teste.php; também pode ser importado sozinho no banco nexus_network_teste.

UPDATE prestador_perfis SET verificado_em = NOW() - INTERVAL 10 DAY
 WHERE usuario_id IN (SELECT prestador_id FROM (
        SELECT prestador_id FROM avaliacoes GROUP BY prestador_id
        HAVING COUNT(*) >= 3 AND AVG(nota) >= 4.3 ORDER BY AVG(nota) DESC, COUNT(*) DESC LIMIT 12) t);

-- 400 buscas nos últimos 60 dias; as categorias 1 e 4 são as mais procuradas.
INSERT INTO buscas (categoria_id, termo, resultados, criado_em)
SELECT CASE WHEN n % 11 < 3 THEN 1 WHEN n % 11 < 5 THEN 4 WHEN n % 11 = 5 THEN 3 WHEN n % 11 = 6 THEN 5
            WHEN n % 11 = 7 THEN 6 WHEN n % 11 = 8 THEN 2 WHEN n % 11 = 9 THEN 7 ELSE NULL END,
       CASE WHEN n % 11 = 10 THEN ELT(1 + n % 5, 'eletricista', 'diarista', 'aula de inglês', 'pintor', 'manicure') ELSE NULL END,
       1 + n % 9,
       NOW() - INTERVAL (n * 37 % 60) DAY - INTERVAL (n * 53 % 1440) MINUTE
FROM (SELECT a.n + b.n * 10 + c.n * 100 AS n
      FROM (SELECT 0 n UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) a,
           (SELECT 0 n UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) b,
           (SELECT 0 n UNION SELECT 1 UNION SELECT 2 UNION SELECT 3) c) nums
WHERE n < 400;

-- Denúncias de exemplo: 3 abertas (2 em avaliações, 1 em perfil) e 1 já descartada.
INSERT INTO denuncias (denunciante_id, prestador_id, avaliacao_id, motivo, detalhes, status, resolvido_em, criado_em)
SELECT p.id, NULL, a.id, 'ofensivo', 'O comentário usa palavras ofensivas.', 'aberta', NULL, NOW() - INTERVAL 1 DAY
FROM (SELECT id, prestador_id FROM avaliacoes ORDER BY id LIMIT 1 OFFSET 4) a
JOIN (SELECT id FROM usuarios WHERE tipo = 'cliente' ORDER BY id LIMIT 1) p;

INSERT INTO denuncias (denunciante_id, prestador_id, avaliacao_id, motivo, detalhes, status, resolvido_em, criado_em)
SELECT a.prestador_id, NULL, a.id, 'falso', 'Nunca prestei serviço para essa pessoa.', 'aberta', NULL, NOW() - INTERVAL 3 HOUR
FROM (SELECT id, prestador_id FROM avaliacoes ORDER BY id LIMIT 1 OFFSET 9) a;

INSERT INTO denuncias (denunciante_id, prestador_id, avaliacao_id, motivo, detalhes, status, resolvido_em, criado_em)
SELECT c.id, p.id, NULL, 'golpe', 'Pediu pagamento adiantado e não apareceu.', 'aberta', NULL, NOW() - INTERVAL 2 DAY
FROM (SELECT id FROM usuarios WHERE tipo = 'cliente' ORDER BY id LIMIT 1 OFFSET 2) c
JOIN (SELECT id FROM usuarios WHERE tipo = 'prestador' ORDER BY id LIMIT 1 OFFSET 6) p;

INSERT INTO denuncias (denunciante_id, prestador_id, avaliacao_id, motivo, detalhes, status, resolvido_em, criado_em)
SELECT c.id, p.id, NULL, 'spam', 'Perfil com divulgação repetida.', 'descartada', NOW() - INTERVAL 5 DAY, NOW() - INTERVAL 6 DAY
FROM (SELECT id FROM usuarios WHERE tipo = 'cliente' ORDER BY id LIMIT 1 OFFSET 5) c
JOIN (SELECT id FROM usuarios WHERE tipo = 'prestador' ORDER BY id LIMIT 1 OFFSET 9) p;
